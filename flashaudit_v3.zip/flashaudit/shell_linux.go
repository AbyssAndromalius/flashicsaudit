//go:build linux

package main

func shellBin() string { return "/bin/sh" }
