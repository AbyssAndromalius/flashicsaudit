package main

import (
	"fmt"
	"math/rand"
	"net"
	"sort"
	"strings"
	"sync"
	"time"
)

// ScanStealth adds random jitter between probes to reduce IDS/NetFlow signature.
// Set via --stealth flag.
var ScanStealth bool

// ScanResult holds findings from an active scan of one host.
type ScanResult struct {
	IP    string         `json:"ip"`
	Open  []OpenPort     `json:"open"`
	Tags  []string       `json:"tags,omitempty"`
}

type OpenPort struct {
	Port    int    `json:"port"`
	Service string `json:"service,omitempty"`
	Banner  string `json:"banner,omitempty"`
}

// scanPorts to probe on each discovered host (ordered by red-team interest).
var scanPorts = []int{
	// ICS/OT first
	502, 44818, 102, 20000, 4840, 47808, 2404, 9600, 1962, 2222, 38589,
	// Management & lateral movement
	22, 23, 3389, 5900, 5985, 445, 139, 135,
	// Web / services
	80, 443, 8080, 8443,
	// Databases
	3306, 5432, 1433, 27017, 6379,
	// Auth
	389, 636, 88,
	// Misc
	21, 161, 623, 515,
}

const (
	scanTimeout   = 400 * time.Millisecond
	bannerTimeout = 600 * time.Millisecond
	maxConcurrent = 200
	stealthMax    = 50 // max goroutines in stealth mode
)


// ActiveScan probes all /24 subnets derived from local interfaces + known
// neighbors, returns findings and injects them as report entries.
func ActiveScan(r *Report) []ScanResult {
	targets := buildScanTargets(r)
	if len(targets) == 0 {
		return nil
	}

	fmt.Fprintf(logWriter, "[scan] %d hôtes cibles sur %d ports...\n", len(targets), len(scanPorts))

	concurrency := maxConcurrent
	if ScanStealth {
		concurrency = stealthMax
	}
	sem := make(chan struct{}, concurrency)
	var mu sync.Mutex
	var results []ScanResult
	var wg sync.WaitGroup

	for _, ip := range targets {
		wg.Add(1)
		go func(ip string) {
			defer wg.Done()
			sem <- struct{}{}
			defer func() { <-sem }()
			if ScanStealth {
				// random jitter 0–250ms per host to blur the scan pattern
				time.Sleep(time.Duration(rand.Intn(250)) * time.Millisecond)
			}
			sr := probeHost(ip)
			if len(sr.Open) > 0 {
				mu.Lock()
				results = append(results, sr)
				mu.Unlock()
			}
		}(ip)
	}
	wg.Wait()

	sort.Slice(results, func(i, j int) bool { return results[i].IP < results[j].IP })
	injectScanFindings(r, results)
	return results
}

func probeHost(ip string) ScanResult {
	sr := ScanResult{IP: ip}
	var mu sync.Mutex
	var wg sync.WaitGroup
	sem := make(chan struct{}, 50)

	for _, port := range scanPorts {
		wg.Add(1)
		go func(p int) {
			defer wg.Done()
			sem <- struct{}{}
			defer func() { <-sem }()

			addr := fmt.Sprintf("%s:%d", ip, p)
			conn, err := net.DialTimeout("tcp4", addr, scanTimeout)
			if err != nil {
				return
			}
			conn.Close()

			op := OpenPort{Port: p, Service: serviceName(p)}
			// ICS protocol identification — dedicated probes
			if icsOTPorts[p] {
				if id := probeICS(ip, p); id != "" {
					op.Banner = id
				}
			} else if bannerPort[p] {
				// re-dial for banner grab on text protocols
				if bc, err2 := net.DialTimeout("tcp4", addr, scanTimeout); err2 == nil {
					bc.SetReadDeadline(time.Now().Add(bannerTimeout))
					buf := make([]byte, 256)
					n, _ := bc.Read(buf)
					bc.Close()
					if n > 0 {
						op.Banner = strings.TrimSpace(sanitize(string(buf[:n])))
					}
				}
			}
			mu.Lock()
			sr.Open = append(sr.Open, op)
			mu.Unlock()
		}(port)
	}
	wg.Wait()

	sort.Slice(sr.Open, func(i, j int) bool { return sr.Open[i].Port < sr.Open[j].Port })
	tagHost(&sr)
	return sr
}

var bannerPort = map[int]bool{
	21: true, 22: true, 23: true, 80: true, 110: true, 143: true,
	443: true, 502: true, 8080: true, 8443: true,
}

func tagHost(sr *ScanResult) {
	ports := map[int]bool{}
	for _, op := range sr.Open {
		ports[op.Port] = true
	}
	if ports[502] || ports[44818] || ports[102] || ports[20000] || ports[4840] || ports[47808] || ports[2404] {
		sr.Tags = appendUniq(sr.Tags, "ICS/OT")
	}
	if ports[3389] {
		sr.Tags = appendUniq(sr.Tags, "RDP")
	}
	if ports[445] || ports[139] {
		sr.Tags = appendUniq(sr.Tags, "SMB")
	}
	if ports[22] {
		sr.Tags = appendUniq(sr.Tags, "SSH")
	}
	if ports[23] {
		sr.Tags = appendUniq(sr.Tags, "TELNET")
	}
	if ports[80] || ports[443] || ports[8080] || ports[8443] {
		sr.Tags = appendUniq(sr.Tags, "WEB")
	}
}

func injectScanFindings(r *Report, results []ScanResult) {
	for i := range results {
		sr := &results[i]
		if len(sr.Open) == 0 {
			continue
		}

		// Honeypot detection — run only on hosts with ICS ports
		hasICS := false
		for _, op := range sr.Open {
			if icsOTPorts[op.Port] {
				hasICS = true
				break
			}
		}
		var verdict HoneypotVerdict
		if hasICS {
			verdict = AnalyzeHoneypot(sr.IP, sr)
			if verdict.Suspect {
				sr.Tags = appendUniq(sr.Tags, "HONEYPOT?")
				fmt.Fprintf(logWriter, "[honeypot] %s SUSPECT (score=%d) : %s\n",
					sr.IP, verdict.Score, strings.Join(verdict.Reasons, " | "))
			}
		}

		sev := Low
		if verdict.Suspect {
			// Downgrade to Info — don't attack what might be a trap
			sev = Info
		} else {
			for _, op := range sr.Open {
				if icsOTPorts[op.Port] {
					sev = Critical
					break
				}
				risky := map[int]bool{23: true, 3389: true, 445: true, 5900: true}
				if risky[op.Port] && sev < High {
					sev = High
				}
			}
		}

		var ev []string
		for _, op := range sr.Open {
			e := fmt.Sprintf("%s:%d", sr.IP, op.Port)
			if op.Service != "" {
				e += fmt.Sprintf(" (%s)", op.Service)
			}
			if op.Banner != "" {
				e += fmt.Sprintf(" banner=%q", op.Banner)
			}
			ev = append(ev, e)
		}
		if verdict.Suspect {
			ev = append(ev, "⚠ HONEYPOT SUSPECT — raisons : "+strings.Join(verdict.Reasons, " | "))
		}

		title := fmt.Sprintf("%s — %d port(s) [%s]", sr.IP, len(sr.Open), strings.Join(sr.Tags, ","))
		detail := "Hôte découvert par scan actif."
		if verdict.Suspect {
			detail = fmt.Sprintf("ATTENTION : hôte suspect honeypot (score=%d). Ne pas attaquer avant vérification manuelle.", verdict.Score)
		}
		r.Add(sev, "Scan", title, detail, ev...)
	}
}

// knownRanges are pre-seeded from the INL 301 lab topology (DMZ + Corporate).
// Any /24 discovered locally also gets added automatically.
var knownRanges []string

// buildScanTargets collects IPs to scan: known ranges + local /24s + ARP neighbors.
func buildScanTargets(r *Report) []string {
	seen := map[string]bool{}
	var targets []string

	addTarget := func(ip string) {
		if !seen[ip] {
			seen[ip] = true
			targets = append(targets, ip)
		}
	}

	expandCIDR := func(cidr string) {
		_, ipNet, err := net.ParseCIDR(cidr)
		if err != nil {
			return
		}
		for host := cloneIP(ipNet.IP); ipNet.Contains(host); incIP(host) {
			h := host.String()
			if isNetworkOrBroadcast(host, ipNet) {
				continue
			}
			addTarget(h)
		}
	}

	// Pre-seed known lab ranges (INL 301 topology)
	for _, r := range knownRanges {
		expandCIDR(r)
	}

	// Expand each local interface's /24
	for _, iface := range r.Network.Interfaces {
		for _, addr := range iface.Addrs {
			ip, ipNet, err := net.ParseCIDR(addr)
			if err != nil || ip.IsLoopback() || ip.To4() == nil {
				continue
			}
			// Force /24 from the interface address
			cidr24 := fmt.Sprintf("%d.%d.%d.0/24", ip[12], ip[13], ip[14])
			_ = ipNet
			expandCIDR(cidr24)
		}
	}

	// ARP neighbors — may reveal non-local segments
	for _, nb := range r.Network.Neighbors {
		addTarget(nb.IP)
		// also expand their /24
		if ip := net.ParseIP(nb.IP); ip != nil && ip.To4() != nil {
			cidr24 := fmt.Sprintf("%d.%d.%d.0/24", ip.To4()[0], ip.To4()[1], ip.To4()[2])
			expandCIDR(cidr24)
		}
	}

	return targets
}

func cloneIP(ip net.IP) net.IP {
	clone := make(net.IP, len(ip))
	copy(clone, ip)
	return clone
}

func incIP(ip net.IP) {
	for j := len(ip) - 1; j >= 0; j-- {
		ip[j]++
		if ip[j] != 0 {
			break
		}
	}
}

func isNetworkOrBroadcast(ip net.IP, n *net.IPNet) bool {
	// network address: all host bits zero
	network := n.IP
	if ip.Equal(network) {
		return true
	}
	// broadcast: all host bits one
	broadcast := make(net.IP, len(network))
	for i := range network {
		broadcast[i] = network[i] | ^n.Mask[i]
	}
	return ip.Equal(broadcast)
}

func sanitize(s string) string {
	var b strings.Builder
	for _, r := range s {
		if r >= 0x20 && r < 0x7f {
			b.WriteRune(r)
		} else if r == '\n' || r == '\r' || r == '\t' {
			b.WriteRune(' ')
		}
	}
	return b.String()
}
