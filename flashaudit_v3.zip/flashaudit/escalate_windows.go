//go:build windows

package main

func TryEscalate(r *Report, execCmd string) {
	r.Add(Info, "LPE", "CopyFail non supporté sous Windows", "Linux uniquement.")
}
func TryDirtyFrag(r *Report, execCmd string) {
	r.Add(Info, "LPE", "DirtyFrag non supporté sous Windows", "Linux uniquement.")
}
func CheckKernelVulnCopyFail(r *Report) bool  { return false }
func CheckKernelVulnDirtyFrag(r *Report) bool { return false }
