package main

import (
	"fmt"
	"net"
	"sort"
	"strings"
)

type Iface struct {
	Name  string   `json:"name"`
	MAC   string   `json:"mac,omitempty"`
	Addrs []string `json:"addrs"`
	Flags string   `json:"flags"`
}

type Listener struct {
	Proto    string `json:"proto"`
	Addr     string `json:"addr"`
	Port     int    `json:"port"`
	Service  string `json:"service,omitempty"`
	Exposure string `json:"exposure"` // local | lan | public
	PID      int    `json:"pid,omitempty"`
	Process  string `json:"process,omitempty"`
}

type Peer struct {
	IP        string   `json:"ip"`
	Scope     string   `json:"scope"` // private | public | loopback
	Direction string   `json:"direction"`
	Ports     []string `json:"ports"`
	Processes []string `json:"processes,omitempty"`
	Count     int      `json:"count"`
}

type Neighbor struct {
	IP    string `json:"ip"`
	MAC   string `json:"mac"`
	Iface string `json:"iface,omitempty"`
}

type NetworkInfo struct {
	Interfaces []Iface    `json:"interfaces"`
	Gateways   []string   `json:"gateways"`
	DNS        []string   `json:"dns"`
	Listeners  []Listener `json:"listeners"`
	Peers      []Peer     `json:"peers"`
	Neighbors  []Neighbor `json:"neighbors,omitempty"`
}

// raw connection, filled by OS-specific collectors
type conn struct {
	proto      string
	localAddr  string
	localPort  int
	remoteAddr string
	remotePort int
	state      string
	pid        int
	process    string
}

// Common well-known ports -> service name
var wellKnown = map[int]string{
	21: "ftp", 22: "ssh", 23: "telnet", 25: "smtp", 53: "dns", 80: "http",
	88: "kerberos", 110: "pop3", 111: "rpcbind", 123: "ntp", 135: "msrpc",
	137: "netbios", 138: "netbios", 139: "netbios-ssn", 143: "imap", 161: "snmp",
	389: "ldap", 443: "https", 445: "smb", 464: "kpasswd", 465: "smtps",
	514: "syslog", 515: "printer", 587: "submission", 593: "rpc-http", 623: "ipmi",
	636: "ldaps", 993: "imaps", 995: "pop3s", 1433: "mssql", 1521: "oracle",
	1723: "pptp", 2049: "nfs", 3268: "gc-ldap", 3306: "mysql", 3389: "rdp",
	3690: "svn", 5060: "sip", 5432: "postgres", 5900: "vnc",
	5985: "winrm", 5986: "winrm-s", 6379: "redis", 8000: "http-alt", 8080: "http-proxy",
	8443: "https-alt", 9200: "elasticsearch", 11211: "memcached", 27017: "mongodb",
	// ICS / OT protocols
	102:   "s7comm",       // Siemens S7 / TPKT
	502:   "modbus",       // Modbus TCP
	1962:  "pcworx",       // Phoenix Contact PCWorx
	2222:  "ethernet-ip",  // EtherNet/IP (implicit messaging)
	4840:  "opc-ua",       // OPC UA
	9600:  "omron-fins",   // Omron FINS/TCP
	18245: "ge-srtp",      // GE SRTP
	20000: "dnp3",         // DNP3
	44818: "ethernet-ip",  // EtherNet/IP (Rockwell/AB explicit)
	47808: "bacnet",       // BACnet/IP
	1089:  "ff-annunc",    // Foundation Fieldbus
	1090:  "ff-fms",       // Foundation Fieldbus
	1091:  "ff-sm",        // Foundation Fieldbus
	34962: "profinet",     // PROFINET RT
	34963: "profinet",     // PROFINET RT
	2404:  "iec104",       // IEC 60870-5-104
	4000:  "iccp",         // ICCP / TASE.2
	10307: "abb-rpc",      // ABB RPC
	38589: "codesys",      // CODESYS runtime
}

var icsOTPorts = map[int]bool{
	102: true, 502: true, 1962: true, 2222: true, 4840: true, 9600: true,
	18245: true, 20000: true, 44818: true, 47808: true, 1089: true, 1090: true,
	1091: true, 34962: true, 34963: true, 2404: true, 4000: true, 10307: true,
	38589: true,
}

func serviceName(port int) string {
	if s, ok := wellKnown[port]; ok {
		return s
	}
	return ""
}

func parseIP(s string) net.IP {
	// handle IPv6 zone and brackets
	s = strings.Trim(s, "[]")
	if i := strings.Index(s, "%"); i >= 0 {
		s = s[:i]
	}
	return net.ParseIP(s)
}

func ipScope(ip net.IP) string {
	if ip == nil {
		return "unknown"
	}
	if ip.IsLoopback() {
		return "loopback"
	}
	if ip.IsPrivate() || ip.IsLinkLocalUnicast() || ip.IsLinkLocalMulticast() {
		return "private"
	}
	if ip.IsUnspecified() {
		return "any"
	}
	return "public"
}

func exposure(addr string) string {
	ip := parseIP(addr)
	if ip == nil {
		return "unknown"
	}
	if ip.IsLoopback() {
		return "local"
	}
	if ip.IsUnspecified() {
		return "public" // 0.0.0.0 / :: = toutes interfaces
	}
	if ip.IsPrivate() || ip.IsLinkLocalUnicast() {
		return "lan"
	}
	return "public"
}

// buildNetwork turns raw conns into the structured NetworkInfo (listeners + peers).
func buildNetwork(net_ *NetworkInfo, conns []conn) {
	type peerKey struct{ ip string }
	peerMap := map[string]*Peer{}

	for _, c := range conns {
		isListen := c.state == "LISTEN" || c.state == "LISTENING" ||
			(c.remotePort == 0 && (c.remoteAddr == "" || c.remoteAddr == "0.0.0.0" || c.remoteAddr == "*" || c.remoteAddr == "::"))

		if isListen {
			net_.Listeners = append(net_.Listeners, Listener{
				Proto: c.proto, Addr: c.localAddr, Port: c.localPort,
				Service: serviceName(c.localPort), Exposure: exposure(c.localAddr),
				PID: c.pid, Process: c.process,
			})
			continue
		}

		// established / related connection = relation to another asset
		rip := parseIP(c.remoteAddr)
		if rip == nil || rip.IsUnspecified() {
			continue
		}
		scope := ipScope(rip)
		if scope == "loopback" {
			continue // trafic interne à la machine
		}
		pk := c.remoteAddr
		p, ok := peerMap[pk]
		if !ok {
			p = &Peer{IP: c.remoteAddr, Scope: scope, Direction: "out"}
			peerMap[pk] = p
		}
		p.Count++
		port := fmt.Sprintf("%d", c.remotePort)
		if sn := serviceName(c.remotePort); sn != "" {
			port = fmt.Sprintf("%d/%s", c.remotePort, sn)
		}
		p.Ports = appendUniq(p.Ports, port)
		if c.process != "" {
			p.Processes = appendUniq(p.Processes, c.process)
		}
	}

	for _, p := range peerMap {
		sort.Strings(p.Ports)
		sort.Strings(p.Processes)
		net_.Peers = append(net_.Peers, *p)
	}
	sort.Slice(net_.Peers, func(i, j int) bool {
		if net_.Peers[i].Scope != net_.Peers[j].Scope {
			return net_.Peers[i].Scope > net_.Peers[j].Scope // public avant private
		}
		return net_.Peers[i].Count > net_.Peers[j].Count
	})
	sort.Slice(net_.Listeners, func(i, j int) bool {
		if net_.Listeners[i].Port != net_.Listeners[j].Port {
			return net_.Listeners[i].Port < net_.Listeners[j].Port
		}
		return net_.Listeners[i].Proto < net_.Listeners[j].Proto
	})
}

func appendUniq(s []string, v string) []string {
	for _, e := range s {
		if e == v {
			return s
		}
	}
	return append(s, v)
}

func exposureRank(e string) int {
	switch e {
	case "local":
		return 0
	case "lan":
		return 1
	case "public":
		return 2
	}
	return 0
}

func filterNeighbors(neighbors []Neighbor) []Neighbor {
	var result []Neighbor
	for _, nb := range neighbors {
		ip := net.ParseIP(nb.IP)
		if ip == nil || ip.IsMulticast() {
			continue
		}
		if nb.IP == "255.255.255.255" {
			continue
		}
		mac := strings.ToLower(nb.MAC)
		if strings.Contains(mac, "ff:ff:ff:ff:ff:ff") {
			continue
		}
		result = append(result, nb)
	}
	return result
}

// collectInterfaces is portable (uses net package).
func collectInterfaces(r *Report) {
	ifaces, err := net.Interfaces()
	if err != nil {
		r.Err("interfaces: %v", err)
		return
	}
	for _, i := range ifaces {
		if i.Flags&net.FlagLoopback != 0 {
			continue
		}
		var addrs []string
		aa, _ := i.Addrs()
		for _, a := range aa {
			addrs = append(addrs, a.String())
		}
		flags := "down"
		if i.Flags&net.FlagUp != 0 {
			flags = "up"
		}
		r.Network.Interfaces = append(r.Network.Interfaces, Iface{
			Name: i.Name, MAC: i.HardwareAddr.String(), Addrs: addrs, Flags: flags,
		})
	}
}

// analyzeNetwork generates findings from the collected network state.
// Listeners are deduplicated by (proto, port) so IPv4/IPv6 duplicates produce one finding.
func analyzeNetwork(r *Report) {
	riskyPorts := map[int]bool{
		23: true, 21: true, 3389: true, 445: true, 5900: true,
		6379: true, 3306: true, 5432: true, 27017: true, 9200: true, 11211: true, 1433: true,
	}

	type portKey struct {
		proto string
		port  int
	}
	type portGroup struct {
		svc      string
		maxExp   string
		evidence []string
	}
	seen := map[portKey]*portGroup{}
	var keyOrder []portKey

	for _, l := range r.Network.Listeners {
		k := portKey{l.Proto, l.Port}
		g, ok := seen[k]
		if !ok {
			svc := l.Service
			if svc == "" {
				svc = "inconnu"
			}
			g = &portGroup{svc: svc}
			seen[k] = g
			keyOrder = append(keyOrder, k)
		}
		g.evidence = append(g.evidence, fmt.Sprintf("%s %s:%d pid=%d %s", l.Proto, l.Addr, l.Port, l.PID, l.Process))
		if exposureRank(l.Exposure) > exposureRank(g.maxExp) {
			g.maxExp = l.Exposure
		}
	}

	var ephemeralCount int
	for _, k := range keyOrder {
		g := seen[k]
		if icsOTPorts[k.port] {
			r.Add(Critical, "ICS/OT",
				fmt.Sprintf("Protocole industriel exposé : %s/%d (%s)", strings.ToUpper(k.proto), k.port, g.svc),
				fmt.Sprintf("Un protocole ICS/OT (%s) est accessible. Absence d'authentification typique.", g.svc),
				g.evidence...)
			continue
		}
		if g.maxExp != "public" {
			continue
		}
		if k.port >= 49152 {
			ephemeralCount++
			continue
		}
		sev := Medium
		if riskyPorts[k.port] {
			sev = High
		}
		r.Add(sev, "Réseau",
			fmt.Sprintf("Service exposé : %s/%d (%s)", strings.ToUpper(k.proto), k.port, g.svc),
			fmt.Sprintf("Le service %s écoute sur toutes interfaces.", g.svc),
			g.evidence...)
	}
	if ephemeralCount > 0 {
		r.Add(Info, "Réseau",
			fmt.Sprintf("%d port(s) éphémères exposés (≥49152, RPC/dynamic)", ephemeralCount),
			"Ports dynamiques Windows (RPC, COM+…) — bruit attendu, voir JSON pour le détail.")
	}

	var icsPeers []string
	for _, p := range r.Network.Peers {
		for _, port := range p.Ports {
			for icsPort := range icsOTPorts {
				if strings.HasPrefix(port, fmt.Sprintf("%d/", icsPort)) || port == fmt.Sprintf("%d", icsPort) {
					icsPeers = appendUniq(icsPeers, fmt.Sprintf("%s via %s", p.IP, port))
				}
			}
		}
	}
	if len(icsPeers) > 0 {
		r.Add(Critical, "ICS/OT",
			fmt.Sprintf("Connexions actives vers %d asset(s) industriel(s)", len(icsPeers)),
			"Cet hôte communique activement avec des équipements ICS/OT — pivot potentiel.", icsPeers...)
	}

	var pub []string
	for _, p := range r.Network.Peers {
		if p.Scope == "public" {
			pub = append(pub, fmt.Sprintf("%s ports=%s", p.IP, strings.Join(p.Ports, ",")))
		}
	}
	if len(pub) > 0 {
		r.Add(Info, "Réseau",
			fmt.Sprintf("%d connexion(s) établie(s) vers des IP publiques", len(pub)),
			"Connexions sortantes vers l'extérieur — à corréler avec l'activité attendue.", pub...)
	}
}
