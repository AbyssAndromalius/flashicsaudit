//go:build windows

package main

func shellBin() string { return "cmd.exe" }
