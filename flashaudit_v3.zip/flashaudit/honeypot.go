package main

import (
	"fmt"
	"net"
	"strings"
	"time"
)

// HoneypotVerdict holds the result of honeypot analysis for one host.
type HoneypotVerdict struct {
	Suspect bool
	Score   int    // 0 = clean, ≥3 = suspect
	Reasons []string
}

// honeypotChecks is the list of active probes run against a host.
// Each check returns a score (0 = clean, 1-3 = suspicious) and a reason string.
type hpCheck struct {
	name string
	fn   func(ip string, sr *ScanResult) (int, string)
}

var honeypotChecks = []hpCheck{
	{"port-density", checkPortDensity},
	{"response-time", checkResponseTime},
	{"conpot-s7", checkConpotS7},
	{"conpot-modbus", checkConpotModbus},
	{"conpot-http", checkConpotHTTP},
	{"cross-proto", checkCrossProto},
	{"banner-generic", checkGenericBanner},
}

// AnalyzeHoneypot runs all heuristics against a scan result and returns a verdict.
func AnalyzeHoneypot(ip string, sr *ScanResult) HoneypotVerdict {
	v := HoneypotVerdict{}
	for _, chk := range honeypotChecks {
		score, reason := chk.fn(ip, sr)
		if score > 0 {
			v.Score += score
			v.Reasons = append(v.Reasons, fmt.Sprintf("[%s +%d] %s", chk.name, score, reason))
		}
	}
	v.Suspect = v.Score >= 3
	return v
}

// checkPortDensity flags hosts with an unrealistic number of ICS protocols open.
// Real PLCs rarely expose more than 2-3 services; Conpot exposes everything at once.
func checkPortDensity(_ string, sr *ScanResult) (int, string) {
	icsCount := 0
	for _, op := range sr.Open {
		if icsOTPorts[op.Port] {
			icsCount++
		}
	}
	if icsCount >= 5 {
		return 3, fmt.Sprintf("%d protocoles ICS/OT simultanément — improbable sur un vrai équipement", icsCount)
	}
	if icsCount >= 3 {
		return 1, fmt.Sprintf("%d protocoles ICS/OT simultanément — inhabituel", icsCount)
	}
	return 0, ""
}

// checkResponseTime measures TCP connect latency to port 102 (S7) or 502 (Modbus).
// Honeypots running on VMs respond in <2ms; real PLCs take 5-150ms.
func checkResponseTime(ip string, sr *ScanResult) (int, string) {
	for _, op := range sr.Open {
		if op.Port != 102 && op.Port != 502 {
			continue
		}
		addr := fmt.Sprintf("%s:%d", ip, op.Port)
		samples := make([]time.Duration, 0, 3)
		for i := 0; i < 3; i++ {
			t0 := time.Now()
			conn, err := net.DialTimeout("tcp4", addr, 500*time.Millisecond)
			elapsed := time.Since(t0)
			if err == nil {
				conn.Close()
				samples = append(samples, elapsed)
			}
		}
		if len(samples) == 0 {
			continue
		}
		var total time.Duration
		for _, s := range samples {
			total += s
		}
		avg := total / time.Duration(len(samples))
		if avg < 2*time.Millisecond {
			return 2, fmt.Sprintf("latence TCP port %d très faible (%v moy.) — caractéristique de honeypot VM local", op.Port, avg.Round(time.Microsecond))
		}
		if avg < 5*time.Millisecond {
			return 1, fmt.Sprintf("latence TCP port %d suspecte (%v moy.)", op.Port, avg.Round(time.Microsecond))
		}
	}
	return 0, ""
}

// checkConpotS7 probes port 102 for Conpot's hardcoded S7 identity strings.
// Conpot returns a fixed module name and serial number regardless of query.
func checkConpotS7(ip string, sr *ScanResult) (int, string) {
	hasS7 := false
	for _, op := range sr.Open {
		if op.Port == 102 {
			hasS7 = true
			// Banner already captured by probeICS — check it first
			if strings.Contains(op.Banner, "SIMATIC 300") ||
				strings.Contains(op.Banner, "6ES7 315") ||
				strings.Contains(op.Banner, "88111222") {
				return 3, fmt.Sprintf("banner S7 identique à Conpot par défaut : %q", op.Banner)
			}
		}
	}
	if !hasS7 {
		return 0, ""
	}
	// Active S7 SZL read for module name / serial
	identity := probeS7SZL(ip)
	if identity == "" {
		return 0, ""
	}
	lower := strings.ToLower(identity)
	conpotSigs := []string{
		"simatic 300", "6es7 315", "6es7315",
		"88111222",          // Conpot default serial
		"original siemens",  // Conpot copyright string
	}
	for _, sig := range conpotSigs {
		if strings.Contains(lower, sig) {
			return 3, fmt.Sprintf("SZL S7 signature Conpot détectée : %q", identity)
		}
	}
	return 0, ""
}

// probeS7SZL sends a Read SZL request (ID=0x0011 — module identification)
// and returns a raw string of the response body for signature matching.
func probeS7SZL(ip string) string {
	conn, err := net.DialTimeout("tcp4", ip+":102", 2*time.Second)
	if err != nil {
		return ""
	}
	defer conn.Close()
	conn.SetDeadline(time.Now().Add(4 * time.Second))

	// COTP CR
	conn.Write([]byte{0x03, 0x00, 0x00, 0x16, 0x11, 0xe0, 0x00, 0x00, 0x00, 0x01, 0x00,
		0xc0, 0x01, 0x0a, 0xc1, 0x02, 0x01, 0x00, 0xc2, 0x02, 0x01, 0x02})
	buf := make([]byte, 512)
	n, _ := conn.Read(buf)
	if n < 6 || buf[5] != 0xd0 {
		return ""
	}
	// Setup comm
	conn.Write([]byte{0x03, 0x00, 0x00, 0x19, 0x02, 0xf0, 0x80,
		0x32, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00,
		0xf0, 0x00, 0x00, 0x01, 0x00, 0x01, 0x01, 0xe0})
	conn.Read(buf)

	// SZL Read ID=0x0011 (module identification), index=0x0000
	szlReq := []byte{
		0x03, 0x00, 0x00, 0x21, 0x02, 0xf0, 0x80,
		0x32, 0x07, 0x00, 0x00, 0x00, 0x01, 0x00, 0x08, 0x00, 0x08,
		0x00, 0x01, 0x12, 0x04, 0x11, 0x44, 0x01, 0x00,
		0xff, 0x09, 0x00, 0x04,
		0x00, 0x11, // SZL-ID = 0x0011
		0x00, 0x00, // SZL-Index = 0
	}
	conn.Write(szlReq)
	n, _ = conn.Read(buf)
	if n < 30 {
		return ""
	}
	// Raw bytes → string for signature matching (printable chars only)
	var sb strings.Builder
	for _, b := range buf[:n] {
		if b >= 0x20 && b < 0x7f {
			sb.WriteByte(b)
		}
	}
	return sb.String()
}

// checkConpotModbus probes port 502 for Conpot's hardcoded FC43 Device ID response.
// Conpot returns: Vendor="Schneider Electric", Product="Modicon M340 BMXNOE0100"
func checkConpotModbus(ip string, sr *ScanResult) (int, string) {
	for _, op := range sr.Open {
		if op.Port != 502 {
			continue
		}
		// Banner from probeModbus already contains vendor strings
		lower := strings.ToLower(op.Banner)
		if strings.Contains(lower, "schneider electric") && strings.Contains(lower, "modicon") {
			return 2, fmt.Sprintf("Modbus Device ID = signature Conpot par défaut : %q", op.Banner)
		}
		if strings.Contains(lower, "conpot") {
			return 3, "Modbus Device ID contient 'conpot'"
		}
	}
	return 0, ""
}

// checkConpotHTTP looks for Conpot/honeypot signatures in HTTP banners.
func checkConpotHTTP(ip string, sr *ScanResult) (int, string) {
	for _, op := range sr.Open {
		if op.Port != 80 && op.Port != 8080 {
			continue
		}
		// Quick HTTP GET and check title/server header
		body, server := httpGet(ip, op.Port)
		lower := strings.ToLower(body + server)
		sigs := []string{
			"conpot", "honeypot", "honey pot",
			"siemens ag simatic", // Conpot default S7 web page title
			"bottle/",            // Conpot uses Bottle framework
		}
		for _, sig := range sigs {
			if strings.Contains(lower, sig) {
				return 3, fmt.Sprintf("HTTP signature honeypot : %q (server: %q)", sig, server)
			}
		}
		// Conpot sometimes returns a blank Server header or "Werkzeug"
		if strings.Contains(strings.ToLower(server), "werkzeug") {
			return 1, fmt.Sprintf("HTTP Server: %q — framework Python de développement, inhabituel sur équipement ICS", server)
		}
	}
	return 0, ""
}

// checkCrossProto flags hosts claiming to be multiple incompatible vendor products.
// e.g. S7 banner says "Siemens" but Modbus says "Schneider Electric"
func checkCrossProto(_ string, sr *ScanResult) (int, string) {
	vendors := map[string]string{}
	for _, op := range sr.Open {
		if op.Banner == "" {
			continue
		}
		lower := strings.ToLower(op.Banner)
		var vendor string
		switch {
		case strings.Contains(lower, "siemens"):
			vendor = "siemens"
		case strings.Contains(lower, "schneider") || strings.Contains(lower, "modicon"):
			vendor = "schneider"
		case strings.Contains(lower, "rockwell") || strings.Contains(lower, "allen-bradley"):
			vendor = "rockwell"
		case strings.Contains(lower, "ge ") || strings.Contains(lower, "general electric"):
			vendor = "ge"
		case strings.Contains(lower, "honeywell"):
			vendor = "honeywell"
		}
		if vendor != "" {
			vendors[vendor] = fmt.Sprintf("port %d", op.Port)
		}
	}
	if len(vendors) >= 2 {
		parts := []string{}
		for v, where := range vendors {
			parts = append(parts, fmt.Sprintf("%s (%s)", v, where))
		}
		return 2, "identités vendeur contradictoires sur le même hôte : " + strings.Join(parts, " vs ")
	}
	return 0, ""
}

// checkGenericBanner flags suspiciously generic or empty banners on ICS ports.
func checkGenericBanner(_ string, sr *ScanResult) (int, string) {
	for _, op := range sr.Open {
		if !icsOTPorts[op.Port] {
			continue
		}
		if op.Banner == "" && op.Port == 102 {
			// Port 102 open but no S7 identity — could be a simple TCP responder
			return 1, "port 102 ouvert mais aucune identité S7 retournée"
		}
	}
	return 0, ""
}

// httpGet fetches the root path and returns (body snippet, Server header).
func httpGet(ip string, port int) (string, string) {
	conn, err := net.DialTimeout("tcp4", fmt.Sprintf("%s:%d", ip, port), 2*time.Second)
	if err != nil {
		return "", ""
	}
	defer conn.Close()
	conn.SetDeadline(time.Now().Add(3 * time.Second))
	fmt.Fprintf(conn, "GET / HTTP/1.0\r\nHost: %s\r\nUser-Agent: Mozilla/5.0\r\n\r\n", ip)
	buf := make([]byte, 2048)
	n, _ := conn.Read(buf)
	if n == 0 {
		return "", ""
	}
	raw := string(buf[:n])
	// Extract Server header
	server := ""
	for _, line := range strings.Split(raw, "\r\n") {
		if strings.HasPrefix(strings.ToLower(line), "server:") {
			server = strings.TrimSpace(line[7:])
			break
		}
	}
	// Body = everything after \r\n\r\n
	body := ""
	if idx := strings.Index(raw, "\r\n\r\n"); idx >= 0 {
		body = raw[idx+4:]
		if len(body) > 512 {
			body = body[:512]
		}
	}
	return body, server
}
