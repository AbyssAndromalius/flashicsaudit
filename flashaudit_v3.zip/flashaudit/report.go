package main

import (
	"encoding/json"
	"fmt"
	"io"
	"sort"
	"strings"
	"sync"
	"time"
)

// ---------------------------------------------------------------------------
// Modèle de données du rapport
// ---------------------------------------------------------------------------

type Severity int

const (
	Info Severity = iota
	Low
	Medium
	High
	Critical
)

var sevNames = []string{"INFO", "LOW", "MEDIUM", "HIGH", "CRITICAL"}

func (s Severity) String() string { return sevNames[s] }

func (s Severity) MarshalJSON() ([]byte, error) { return json.Marshal(s.String()) }

type Finding struct {
	Severity Severity `json:"severity"`
	Category string   `json:"category"`
	Title    string   `json:"title"`
	Detail   string   `json:"detail,omitempty"`
	Evidence []string `json:"evidence,omitempty"`
}

type HostInfo struct {
	Hostname       string `json:"hostname"`
	OS             string `json:"os"`
	OSVersion      string `json:"os_version"`
	Kernel         string `json:"kernel,omitempty"`
	Arch           string `json:"arch"`
	Domain         string `json:"domain,omitempty"`
	Uptime         string `json:"uptime,omitempty"`
	IsAdmin        bool   `json:"is_admin"`
	CurrentUser    string `json:"current_user"`
	Virtualization string `json:"virtualization,omitempty"`
}

type Report struct {
	Tool        string       `json:"tool"`
	Version     string       `json:"version"`
	CollectedAt time.Time    `json:"collected_at"`
	Duration    string       `json:"duration"`
	Host        HostInfo     `json:"host"`
	Network     NetworkInfo  `json:"network"`
	ScanResults  []ScanResult  `json:"scan,omitempty"`
	BruteResults []BruteResult `json:"brute,omitempty"`
	Findings     []Finding     `json:"findings"`
	Errors      []string     `json:"errors,omitempty"`
	mu          sync.Mutex
}

func (r *Report) Add(sev Severity, cat, title, detail string, evidence ...string) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.Findings = append(r.Findings, Finding{sev, cat, title, detail, evidence})
}

func (r *Report) Err(format string, a ...interface{}) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.Errors = append(r.Errors, fmt.Sprintf(format, a...))
}

func (r *Report) sortFindings() {
	sort.SliceStable(r.Findings, func(i, j int) bool {
		if r.Findings[i].Severity != r.Findings[j].Severity {
			return r.Findings[i].Severity > r.Findings[j].Severity
		}
		return r.Findings[i].Category < r.Findings[j].Category
	})
}

func (r *Report) counts() map[Severity]int {
	c := map[Severity]int{}
	for _, f := range r.Findings {
		c[f.Severity]++
	}
	return c
}

// ---------------------------------------------------------------------------
// Sorties
// ---------------------------------------------------------------------------

func (r *Report) WriteJSON(w io.Writer) error {
	enc := json.NewEncoder(w)
	enc.SetIndent("", "  ")
	return enc.Encode(r)
}

func mdEsc(s string) string {
	return strings.NewReplacer("|", "\\|", "\n", " ").Replace(s)
}

func (r *Report) WriteMarkdown(w io.Writer) {
	p := func(format string, a ...interface{}) { fmt.Fprintf(w, format, a...) }
	h := r.Host
	c := r.counts()

	p("# Audit éclair — %s\n\n", h.Hostname)
	p("_Collecte : %s — durée %s — %s %s_\n\n",
		r.CollectedAt.Format("2006-01-02 15:04:05 MST"), r.Duration, r.Tool, r.Version)

	p("## Synthèse\n\n")
	p("| CRITICAL | HIGH | MEDIUM | LOW | INFO |\n|---|---|---|---|---|\n")
	p("| %d | %d | %d | %d | %d |\n\n", c[Critical], c[High], c[Medium], c[Low], c[Info])
	if !h.IsAdmin {
		p("> ⚠️ Audit exécuté **sans privilèges administrateur/root** — certains contrôles sont incomplets.\n\n")
	}

	p("## Hôte\n\n| Champ | Valeur |\n|---|---|\n")
	rows := [][2]string{
		{"Nom", h.Hostname}, {"OS", h.OS + " " + h.OSVersion}, {"Noyau / build", h.Kernel},
		{"Architecture", h.Arch}, {"Domaine", h.Domain}, {"Uptime", h.Uptime},
		{"Utilisateur", h.CurrentUser}, {"Admin/root", fmt.Sprint(h.IsAdmin)},
		{"Virtualisation", h.Virtualization},
	}
	for _, row := range rows {
		if row[1] != "" {
			p("| %s | %s |\n", row[0], mdEsc(row[1]))
		}
	}

	// CRITICAL + HIGH → full detail blocks
	p("\n## Constats\n\n")
	hasCritHigh := false
	for _, f := range r.Findings {
		if f.Severity >= High {
			hasCritHigh = true
			writeFindingMD(w, f)
		}
	}

	// MEDIUM + LOW → single compact table
	var medLow []Finding
	for _, f := range r.Findings {
		if f.Severity == Medium || f.Severity == Low {
			medLow = append(medLow, f)
		}
	}
	if len(medLow) > 0 {
		p("| Sév | Catégorie | Constat | Détail |\n|---|---|---|---|\n")
		for _, f := range medLow {
			detail := f.Detail
			if len(detail) > 100 {
				detail = detail[:97] + "…"
			}
			p("| **%s** | %s | %s | %s |\n",
				f.Severity, mdEsc(f.Category), mdEsc(f.Title), mdEsc(detail))
		}
		p("\n")
	} else if !hasCritHigh {
		p("_Aucun constat notable._\n\n")
	}

	n := r.Network
	p("## Réseau\n\n### Interfaces\n\n| Interface | MAC | Adresses | État |\n|---|---|---|---|\n")
	for _, i := range n.Interfaces {
		p("| %s | %s | %s | %s |\n", mdEsc(i.Name), i.MAC, strings.Join(i.Addrs, ", "), i.Flags)
	}
	p("\n- **Passerelle(s)** : %s\n- **DNS** : %s\n\n",
		orDash(strings.Join(n.Gateways, ", ")), orDash(strings.Join(n.DNS, ", ")))

	p("### Ports en écoute\n\n")
	writeListenerTable(w, n.Listeners)

	p("\n### Assets en relation\n\n| IP distante | Portée | Sens | Ports | Processus | Nb |\n|---|---|---|---|---|---|\n")
	for _, pe := range n.Peers {
		p("| %s | %s | %s | %s | %s | %d |\n",
			pe.IP, pe.Scope, pe.Direction,
			strings.Join(pe.Ports, ", "), mdEsc(strings.Join(pe.Processes, ", ")), pe.Count)
	}

	if len(n.Neighbors) > 0 {
		real := filterNeighbors(n.Neighbors)
		if len(real) > 0 {
			p("\n### Voisins ARP\n\n| IP | MAC | Interface |\n|---|---|---|\n")
			for _, nb := range real {
				p("| %s | %s | %s |\n", nb.IP, nb.MAC, nb.Iface)
			}
		}
	}

	// INFO findings → compact bullet list
	var infoF []Finding
	for _, f := range r.Findings {
		if f.Severity == Info {
			infoF = append(infoF, f)
		}
	}
	if len(infoF) > 0 {
		p("\n## Informations complémentaires\n\n")
		for _, f := range infoF {
			detail := f.Detail
			if len(detail) > 120 {
				detail = detail[:117] + "…"
			}
			p("- **%s / %s** — %s\n", f.Category, f.Title, detail)
		}
		p("\n")
	}

	if len(r.Errors) > 0 {
		p("## Limites / erreurs de collecte\n\n")
		for _, e := range r.Errors {
			p("- %s\n", e)
		}
	}
}

// writeListenerTable renders a deduplicated listener table.
// Rows with the same (proto, port, process) are merged; ephemeral ports (≥49152) are summarised.
func writeListenerTable(w io.Writer, listeners []Listener) {
	p := func(format string, a ...interface{}) { fmt.Fprintf(w, format, a...) }

	type key struct {
		proto   string
		port    int
		process string
	}
	type grp struct {
		service   string
		exposure  string
		firstAddr string
		multi     bool
	}

	groups := map[key]*grp{}
	var order []key

	for _, l := range listeners {
		k := key{l.Proto, l.Port, l.Process}
		g, ok := groups[k]
		if !ok {
			g = &grp{service: l.Service, exposure: l.Exposure, firstAddr: l.Addr}
			groups[k] = g
			order = append(order, k)
		} else {
			if l.Addr != g.firstAddr {
				g.multi = true
			}
			if exposureRank(l.Exposure) > exposureRank(g.exposure) {
				g.exposure = l.Exposure
			}
		}
	}

	ephemeralByProc := map[string]int{}
	p("| Proto | Adresse | Port | Service | Exposition | Processus |\n|---|---|---|---|---|---|\n")
	for _, k := range order {
		g := groups[k]
		if k.port >= 49152 {
			proc := k.process
			if proc == "" {
				proc = "?"
			}
			ephemeralByProc[proc]++
			continue
		}
		addr := g.firstAddr
		if g.multi {
			addr = "*"
		}
		p("| %s | %s | %d | %s | %s | %s |\n",
			k.proto, addr, k.port, g.service, g.exposure, mdEsc(k.process))
	}
	for proc, count := range ephemeralByProc {
		p("| tcp | * | ≥49152 | rpc/dynamic | local | %s (%d ports) |\n", mdEsc(proc), count)
	}
}

func writeFindingMD(w io.Writer, f Finding) {
	fmt.Fprintf(w, "### [%s] %s — %s\n\n", f.Severity, f.Category, f.Title)
	if f.Detail != "" {
		fmt.Fprintf(w, "%s\n\n", f.Detail)
	}
	if len(f.Evidence) > 0 {
		ev := f.Evidence
		more := 0
		if len(ev) > 25 {
			more = len(ev) - 25
			ev = ev[:25]
		}
		fmt.Fprintf(w, "```\n%s\n", strings.Join(ev, "\n"))
		if more > 0 {
			fmt.Fprintf(w, "... (+%d, voir JSON)\n", more)
		}
		fmt.Fprintf(w, "```\n\n")
	}
}

func orDash(s string) string {
	if s == "" {
		return "—"
	}
	return s
}

func (r *Report) PrintSummary(w io.Writer) {
	c := r.counts()
	fmt.Fprintf(w, "\n== %s (%s %s) — %s ==\n", r.Host.Hostname, r.Host.OS, r.Host.OSVersion, r.Duration)
	fmt.Fprintf(w, "CRITICAL:%d HIGH:%d MEDIUM:%d LOW:%d INFO:%d | écoute:%d pairs:%d\n",
		c[Critical], c[High], c[Medium], c[Low], c[Info], len(r.Network.Listeners), len(r.Network.Peers))
	for _, f := range r.Findings {
		if f.Severity >= High {
			fmt.Fprintf(w, "  [%s] %s — %s\n", f.Severity, f.Category, f.Title)
		}
	}
}
