package main

import (
	"encoding/binary"
	"fmt"
	"net"
	"strings"
	"time"
)

// probeICS attempts protocol-level identification on known OT ports.
// Returns a human-readable identity string or "".
func probeICS(ip string, port int) string {
	switch port {
	case 102:
		return probeS7(ip)
	case 44818:
		return probeENIP(ip)
	case 502:
		return probeModbus(ip)
	case 47808:
		return probeBACnet(ip)
	case 20000:
		return probeDNP3(ip)
	}
	return ""
}

// ---------------------------------------------------------------------------
// Siemens S7Comm (port 102 / ISO-TSAP)
// ---------------------------------------------------------------------------

func probeS7(ip string) string {
	conn, err := net.DialTimeout("tcp4", ip+":102", 2*time.Second)
	if err != nil {
		return ""
	}
	defer conn.Close()
	conn.SetDeadline(time.Now().Add(3 * time.Second))

	// TPKT + COTP Connection Request (CR) — standard S7 connection setup
	cr := []byte{
		0x03, 0x00, 0x00, 0x16, // TPKT: version=3, reserved=0, len=22
		0x11,                   // COTP: len=17
		0xe0,                   // COTP: PDU type = CR (Connection Request)
		0x00, 0x00,             // dst reference
		0x00, 0x01,             // src reference
		0x00,                   // class / option
		0xc0, 0x01, 0x0a,       // param: tpdu-size=1024
		0xc1, 0x02, 0x01, 0x00, // param: src-tsap (1,0) = PG
		0xc2, 0x02, 0x01, 0x02, // param: dst-tsap (1,2) = S7 resource manager
	}
	if _, err := conn.Write(cr); err != nil {
		return ""
	}
	buf := make([]byte, 256)
	n, err := conn.Read(buf)
	if err != nil || n < 4 {
		return ""
	}
	// Expect TPKT (0x03) + COTP CC (0xd0)
	if buf[0] != 0x03 || (n > 5 && buf[5] != 0xd0) {
		return "S7: connexion TPKT reçue (COTP inattendu)"
	}

	// S7Comm Setup Communication
	setup := []byte{
		0x03, 0x00, 0x00, 0x19, // TPKT
		0x02, 0xf0, 0x80,       // COTP DT
		0x32, 0x01,             // S7 magic, job type = request
		0x00, 0x00,             // redundancy
		0x00, 0x00,             // PDU ref
		0x00, 0x08,             // param len
		0x00, 0x00,             // data len
		0xf0, 0x00,             // func = setup comm
		0x00, 0x01,             // max AMQ calling
		0x00, 0x01,             // max AMQ called
		0x01, 0xe0,             // PDU size = 480
	}
	if _, err := conn.Write(setup); err != nil {
		return "S7: répondant (COTP OK, setup échoué)"
	}
	n, err = conn.Read(buf)
	if err != nil || n < 7 {
		return "S7: répondant"
	}
	if n > 8 && buf[7] == 0x32 && buf[8] == 0x03 {
		return fmt.Sprintf("Siemens S7 — setup comm OK (PDU réponse %d octets)", n)
	}
	return "S7: répondant (réponse setup inattendue)"
}

// ---------------------------------------------------------------------------
// EtherNet/IP ListIdentity (port 44818 / TCP)
// ---------------------------------------------------------------------------

func probeENIP(ip string) string {
	conn, err := net.DialTimeout("tcp4", ip+":44818", 2*time.Second)
	if err != nil {
		return ""
	}
	defer conn.Close()
	conn.SetDeadline(time.Now().Add(3 * time.Second))

	// ListIdentity encapsulation header (24 bytes)
	req := make([]byte, 24)
	binary.LittleEndian.PutUint16(req[0:], 0x0063) // command = ListIdentity
	binary.LittleEndian.PutUint16(req[2:], 0x0000) // length = 0 (no data)
	// session, status, sender context, options = 0
	if _, err := conn.Write(req); err != nil {
		return ""
	}
	buf := make([]byte, 512)
	n, err := conn.Read(buf)
	if err != nil || n < 26 {
		return ""
	}
	if binary.LittleEndian.Uint16(buf[0:]) != 0x0063 {
		return "EtherNet/IP: répondant"
	}
	dataLen := int(binary.LittleEndian.Uint16(buf[2:]))
	if dataLen < 4 || n < 26 {
		return "EtherNet/IP: ListIdentity réponse vide"
	}
	// item count at offset 24
	// item type at 26, item length at 28, then identity object
	if n < 33 {
		return "EtherNet/IP: répondant (réponse courte)"
	}
	// Product name is a counted string starting at offset 50 (typical)
	// Parse minimally: vendor(2), device(2), product(2), revision(2), status(2), serial(4), nameLen(1), name
	base := 26
	if n < base+28 {
		return "EtherNet/IP: répondant"
	}
	// skip item header (4 bytes)
	base += 4
	vendor := binary.LittleEndian.Uint16(buf[base+2:])
	devType := binary.LittleEndian.Uint16(buf[base+4:])
	prod := binary.LittleEndian.Uint16(buf[base+6:])
	revMaj := buf[base+8]
	revMin := buf[base+9]
	serial := binary.LittleEndian.Uint32(buf[base+12:])
	nameLen := int(buf[base+16])
	name := ""
	if nameLen > 0 && n >= base+17+nameLen {
		name = string(buf[base+17 : base+17+nameLen])
	}
	return fmt.Sprintf("EtherNet/IP — vendor=%d devType=%d prod=%d rev=%d.%d serial=%08X name=%q",
		vendor, devType, prod, revMaj, revMin, serial, name)
}

// ---------------------------------------------------------------------------
// Modbus Read Device Identification (FC=43/14) — port 502
// ---------------------------------------------------------------------------

func probeModbus(ip string) string {
	conn, err := net.DialTimeout("tcp4", ip+":502", 2*time.Second)
	if err != nil {
		return ""
	}
	defer conn.Close()
	conn.SetDeadline(time.Now().Add(3 * time.Second))

	// MBAP header + FC43 Read Device Identification (MEI type 0x0E, basic stream)
	req := []byte{
		0x00, 0x01, // transaction ID
		0x00, 0x00, // protocol = Modbus
		0x00, 0x05, // length = 5 bytes follow
		0x01,       // unit ID
		0x2b,       // FC = 43 (Read Device ID)
		0x0e,       // MEI type = 14
		0x01,       // read dev ID code = 1 (basic)
		0x00,       // object ID = 0 (VendorName)
	}
	if _, err := conn.Write(req); err != nil {
		return ""
	}
	buf := make([]byte, 256)
	n, err := conn.Read(buf)
	if err != nil || n < 8 {
		return "Modbus: répondant (pas de réponse FC43)"
	}
	if buf[7] == 0xab {
		return "Modbus: répondant (FC43 non supporté)"
	}
	if buf[7] != 0x2b || n < 14 {
		return "Modbus: répondant"
	}
	objCount := int(buf[13])
	var parts []string
	pos := 14
	for i := 0; i < objCount && pos+2 < n; i++ {
		objLen := int(buf[pos+1])
		if pos+2+objLen > n {
			break
		}
		val := string(buf[pos+2 : pos+2+objLen])
		parts = append(parts, val)
		pos += 2 + objLen
	}
	if len(parts) > 0 {
		return "Modbus — " + strings.Join(parts, " / ")
	}
	return "Modbus: répondant (FC43 OK)"
}

// ---------------------------------------------------------------------------
// DNP3 Data Link Layer probe (port 20000 / TCP)
// ---------------------------------------------------------------------------

// dnp3CRC computes CRC-16/DNP3 (poly=0x3D65 reflected, init=0, xorout=0xFFFF).
func dnp3CRC(data []byte) uint16 {
	var crc uint16
	for _, b := range data {
		crc ^= uint16(b)
		for i := 0; i < 8; i++ {
			if crc&1 != 0 {
				crc = (crc >> 1) ^ 0xA6BC
			} else {
				crc >>= 1
			}
		}
	}
	return ^crc
}

// probeDNP3 sends a DNP3 "Reset of Link" to the device and parses the response
// to extract the station address.
func probeDNP3(ip string) string {
	conn, err := net.DialTimeout("tcp4", ip+":20000", 2*time.Second)
	if err != nil {
		return ""
	}
	defer conn.Close()
	conn.SetDeadline(time.Now().Add(3 * time.Second))

	// Data Link Layer frame: start(2) + len(1) + ctrl(1) + dst(2) + src(2) + crc(2)
	// FC=0 (Reset of Link), PRM=1, DST=0xFFFF (broadcast), SRC=3 (master)
	hdr := []byte{0x05, 0x64, 0x05, 0x40, 0xFF, 0xFF, 0x03, 0x00}
	crc := dnp3CRC(hdr[2:])
	frame := append(hdr, byte(crc), byte(crc>>8))

	if _, err := conn.Write(frame); err != nil {
		return "DNP3: répondant"
	}
	buf := make([]byte, 64)
	n, err := conn.Read(buf)
	if err != nil || n < 8 {
		return "DNP3: répondant (pas de réponse DLL)"
	}
	if buf[0] != 0x05 || buf[1] != 0x64 {
		return "DNP3: répondant (frame non-DNP3)"
	}
	// Source address of the response = device DNP3 station address
	stationAddr := uint16(buf[6]) | uint16(buf[7])<<8
	ctrl := buf[3]
	fc := ctrl & 0x0F
	fcNames := map[byte]string{0: "ACK", 1: "NACK", 11: "Link Status"}
	fcName, ok := fcNames[fc]
	if !ok {
		fcName = fmt.Sprintf("FC=%d", fc)
	}
	return fmt.Sprintf("DNP3 — station=%d ctrl=0x%02X (%s)", stationAddr, ctrl, fcName)
}

// ---------------------------------------------------------------------------
// BACnet Who-Is (port 47808 / UDP)
// ---------------------------------------------------------------------------

func probeBACnet(ip string) string {
	conn, err := net.DialTimeout("udp4", ip+":47808", 2*time.Second)
	if err != nil {
		return ""
	}
	defer conn.Close()
	conn.SetDeadline(time.Now().Add(2 * time.Second))

	// BACnet/IP BVLC Original-Unicast-NPDU + Who-Is APDU (broadcast range 0–4194303)
	req := []byte{
		0x81, 0x0a,             // BVLC type, function = Original-Unicast-NPDU
		0x00, 0x11,             // BVLC length = 17
		0x01, 0x04,             // NPDU version=1, control=4
		0x00, 0x05,             // NPDU destination network (0=local)
		0x10, 0x08,             // APDU: unconfirmed-req, service=Who-Is
		0x09, 0x00,             // low limit = 0
		0x19, 0xff,             // high limit = 255
	}
	if _, err := conn.Write(req); err != nil {
		return ""
	}
	buf := make([]byte, 256)
	n, err := conn.Read(buf)
	if err != nil || n < 9 {
		return ""
	}
	if buf[0] == 0x81 {
		return fmt.Sprintf("BACnet/IP — répondant (%d octets I-Am)", n)
	}
	return ""
}
