//go:build windows

package main

import (
	"fmt"
	"os"
	"os/exec"
	"os/user"
	"strconv"
	"strings"
)

func collectHost(r *Report) {
	h := &r.Host
	h.OS = "windows"
	h.Arch = os.Getenv("PROCESSOR_ARCHITECTURE")
	hn, _ := os.Hostname()
	h.Hostname = hn
	if u, err := user.Current(); err == nil {
		h.CurrentUser = u.Username
	}
	h.IsAdmin = isAdminWindows()
	h.OSVersion = wmiOrReg()
	h.Domain = os.Getenv("USERDOMAIN")
	if cs := runPS(`(Get-CimInstance Win32_ComputerSystem).Domain`); cs != "" {
		h.Domain = cs
	}
	h.Virtualization = detectVirtWindows()
}

func isAdminWindows() bool {
	// "net session" ne réussit que pour un administrateur
	err := exec.Command("net", "session").Run()
	return err == nil
}

func wmiOrReg() string {
	v := runPS(`(Get-CimInstance Win32_OperatingSystem).Caption + " " + (Get-CimInstance Win32_OperatingSystem).Version`)
	if v != "" {
		return v
	}
	return runPS(`(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion").ProductName`)
}

func detectVirtWindows() string {
	return runPS(`(Get-CimInstance Win32_ComputerSystem).Model`)
}

func runPS(script string) string {
	out, err := exec.Command("powershell", "-NoProfile", "-NonInteractive", "-Command", script).Output()
	if err != nil {
		return ""
	}
	return strings.TrimSpace(string(out))
}

// --------------------------- Checks système Windows ---------------------------

func collectSystemChecks(r *Report) {
	checkDefenderWin(r)
	checkFirewallWin(r)
	checkRDPWin(r)
	checkSMBWin(r)
	checkLocalAdminsWin(r)
	checkUACWin(r)
	checkAutorunsWin(r)
	checkSharesWin(r)
	checkSecretsWin(r)
	checkPatchWin(r)
}

func checkDefenderWin(r *Report) {
	out := runPS(`$s=Get-MpComputerStatus -ErrorAction SilentlyContinue; if($s){"$($s.RealTimeProtectionEnabled)|$($s.AntivirusEnabled)|$($s.AntivirusSignatureAge)"}`)
	if out == "" {
		return
	}
	f := strings.Split(out, "|")
	if len(f) >= 2 && strings.EqualFold(f[0], "False") {
		r.Add(High, "Antivirus", "Protection en temps réel Defender désactivée", "La protection temps réel de Microsoft Defender est inactive.", out)
	}
	if len(f) >= 3 {
		if age, err := strconv.Atoi(f[2]); err == nil && age > 7 {
			r.Add(Medium, "Antivirus", fmt.Sprintf("Signatures AV anciennes (%d jours)", age), "Les signatures Defender n'ont pas été mises à jour récemment.", out)
		}
	}
}

func checkFirewallWin(r *Report) {
	out := runPS(`Get-NetFirewallProfile | ForEach-Object { "$($_.Name)=$($_.Enabled)" }`)
	for _, line := range strings.Split(out, "\n") {
		line = strings.TrimSpace(line)
		if strings.HasSuffix(strings.ToLower(line), "=false") {
			r.Add(Medium, "Durcissement", "Profil de pare-feu désactivé : "+line, "Un profil du pare-feu Windows est désactivé.", line)
		}
	}
}

func checkRDPWin(r *Report) {
	v := runPS(`(Get-ItemProperty "HKLM:\System\CurrentControlSet\Control\Terminal Server").fDenyTSConnections`)
	if v == "0" {
		nla := runPS(`(Get-ItemProperty "HKLM:\System\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp").UserAuthentication`)
		detail := "RDP est activé."
		sev := Info
		if nla == "0" {
			detail = "RDP est activé SANS Network Level Authentication (NLA)."
			sev = High
		}
		r.Add(sev, "Accès distant", "RDP activé", detail, "fDenyTSConnections=0, NLA="+nla)
	}
}

func checkSMBWin(r *Report) {
	v := runPS(`(Get-SmbServerConfiguration -ErrorAction SilentlyContinue).EnableSMB1Protocol`)
	if strings.EqualFold(v, "True") {
		r.Add(High, "Durcissement", "SMBv1 activé", "Le protocole obsolète et vulnérable SMBv1 est activé.", "EnableSMB1Protocol=True")
	}
	sign := runPS(`(Get-SmbServerConfiguration -ErrorAction SilentlyContinue).RequireSecuritySignature`)
	if strings.EqualFold(sign, "False") {
		r.Add(Medium, "Durcissement", "Signature SMB non requise", "La signature SMB n'est pas imposée (risque de relais).", "RequireSecuritySignature=False")
	}
}

func checkLocalAdminsWin(r *Report) {
	out := runPS(`Get-LocalGroupMember -Group "Administrators" -ErrorAction SilentlyContinue | ForEach-Object { $_.Name }`)
	if out == "" {
		out = runPS(`net localgroup Administrators`)
	}
	var members []string
	for _, l := range strings.Split(out, "\n") {
		l = strings.TrimSpace(l)
		if l != "" {
			members = append(members, l)
		}
	}
	if len(members) > 0 {
		r.Add(Info, "Comptes", fmt.Sprintf("%d membre(s) du groupe Administrateurs", len(members)), "Membres du groupe Administrateurs local.", members...)
	}
}

func checkUACWin(r *Report) {
	v := runPS(`(Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System").EnableLUA`)
	if v == "0" {
		r.Add(High, "Durcissement", "UAC désactivé", "Le contrôle de compte utilisateur (EnableLUA) est désactivé.", "EnableLUA=0")
	}
}

func checkAutorunsWin(r *Report) {
	keys := []string{
		`HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run`,
		`HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run`,
	}
	var ev []string
	for _, k := range keys {
		out := runPS(fmt.Sprintf(`$p=Get-ItemProperty "%s" -ErrorAction SilentlyContinue; if($p){$p.PSObject.Properties | Where-Object {$_.Name -notlike "PS*"} | ForEach-Object {"$($_.Name) = $($_.Value)"}}`, k))
		for _, l := range strings.Split(out, "\n") {
			if strings.TrimSpace(l) != "" {
				ev = append(ev, strings.TrimSpace(l))
			}
		}
	}
	if len(ev) > 0 {
		r.Add(Info, "Persistance", fmt.Sprintf("%d entrée(s) d'exécution automatique", len(ev)), "Programmes lancés au démarrage (clés Run) — à inspecter.", ev...)
	}
}

func checkSharesWin(r *Report) {
	out := runPS(`Get-SmbShare -ErrorAction SilentlyContinue | Where-Object { $_.Name -notmatch '^\w\$$' -and $_.Name -ne 'IPC$' } | ForEach-Object { "$($_.Name) -> $($_.Path)" }`)
	var ev []string
	for _, l := range strings.Split(out, "\n") {
		if strings.TrimSpace(l) != "" {
			ev = append(ev, strings.TrimSpace(l))
		}
	}
	if len(ev) > 0 {
		r.Add(Low, "Partages", fmt.Sprintf("%d partage(s) réseau non administratif(s)", len(ev)), "Partages SMB exposés — vérifier les permissions.", ev...)
	}
}

func checkSecretsWin(r *Report) {
	profile := os.Getenv("USERPROFILE")
	candidates := []string{
		profile + `\.ssh`,
		profile + `\.aws\credentials`,
		profile + `\AppData\Roaming\Microsoft\Credentials`,
	}
	var ev []string
	for _, c := range candidates {
		if fi, err := os.Stat(c); err == nil {
			ev = append(ev, fmt.Sprintf("%s (%s)", c, fi.Mode()))
		}
	}
	// recherche de clés privées non chiffrées
	sshDir := profile + `\.ssh`
	if entries, err := os.ReadDir(sshDir); err == nil {
		for _, e := range entries {
			b, _ := os.ReadFile(sshDir + `\` + e.Name())
			if strings.Contains(string(b), "PRIVATE KEY") && !strings.Contains(string(b), "ENCRYPTED") {
				r.Add(High, "Secrets", "Clé SSH privée non chiffrée", "Clé privée présente sans passphrase.", sshDir+`\`+e.Name())
			}
		}
	}
	if len(ev) > 0 {
		r.Add(Info, "Secrets", "Emplacements de secrets détectés", "Répertoires/fichiers d'identifiants présents.", ev...)
	}
}

func checkPatchWin(r *Report) {
	out := runPS(`Get-HotFix -ErrorAction SilentlyContinue | Sort-Object InstalledOn -Descending | Select-Object -First 1 | ForEach-Object { "$($_.HotFixID) $($_.InstalledOn)" }`)
	if out != "" {
		r.Add(Info, "Correctifs", "Dernier correctif installé", "Dernier KB appliqué sur le système.", out)
	}
}

// --------------------------- Réseau Windows ---------------------------

func collectConns(r *Report) []conn {
	collectInterfaces(r)
	r.Network.Gateways = winGateways()
	r.Network.DNS = winDNS()
	r.Network.Neighbors = winNeighbors()

	pidName := winProcMap()
	var conns []conn
	out, err := exec.Command("netstat", "-ano").Output()
	if err != nil {
		r.Err("netstat: %v", err)
		return conns
	}
	for _, line := range strings.Split(string(out), "\n") {
		f := strings.Fields(line)
		if len(f) < 4 {
			continue
		}
		proto := strings.ToLower(f[0])
		if proto != "tcp" && proto != "udp" {
			continue
		}
		la, lp := splitHostPort(f[1])
		var ra string
		var rp int
		var state string
		var pidStr string
		if proto == "tcp" && len(f) >= 5 {
			ra, rp = splitHostPort(f[2])
			state = f[3]
			pidStr = f[4]
		} else { // udp : pas d'état
			ra, rp = splitHostPort(f[2])
			state = "ESTABLISHED"
			if f[2] == "*:*" {
				state = "LISTEN"
			}
			pidStr = f[len(f)-1]
		}
		pid, _ := strconv.Atoi(pidStr)
		conns = append(conns, conn{
			proto: proto, localAddr: la, localPort: lp, remoteAddr: ra, remotePort: rp,
			state: normState(state), pid: pid, process: pidName[pid],
		})
	}
	return conns
}

func normState(s string) string {
	s = strings.ToUpper(s)
	if s == "LISTENING" {
		return "LISTEN"
	}
	return s
}

func splitHostPort(s string) (string, int) {
	i := strings.LastIndex(s, ":")
	if i < 0 {
		return s, 0
	}
	host := strings.Trim(s[:i], "[]")
	port, _ := strconv.Atoi(s[i+1:])
	if host == "*" {
		host = "0.0.0.0"
	}
	return host, port
}

func winProcMap() map[int]string {
	m := map[int]string{}
	out, err := exec.Command("tasklist", "/fo", "csv", "/nh").Output()
	if err != nil {
		return m
	}
	for _, line := range strings.Split(string(out), "\n") {
		parts := strings.Split(line, "\",\"")
		if len(parts) < 2 {
			continue
		}
		name := strings.Trim(parts[0], "\"")
		pid, _ := strconv.Atoi(strings.Trim(parts[1], "\""))
		if pid != 0 {
			m[pid] = name
		}
	}
	return m
}

func winGateways() []string {
	out := runPS(`(Get-NetRoute -DestinationPrefix "0.0.0.0/0" -ErrorAction SilentlyContinue).NextHop`)
	var gw []string
	for _, l := range strings.Split(out, "\n") {
		if strings.TrimSpace(l) != "" {
			gw = appendUniq(gw, strings.TrimSpace(l))
		}
	}
	return gw
}

func winDNS() []string {
	out := runPS(`Get-DnsClientServerAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | ForEach-Object { $_.ServerAddresses } | Select-Object -Unique`)
	var dns []string
	for _, l := range strings.Split(out, "\n") {
		if strings.TrimSpace(l) != "" {
			dns = append(dns, strings.TrimSpace(l))
		}
	}
	return dns
}

func winNeighbors() []Neighbor {
	out, err := exec.Command("arp", "-a").Output()
	if err != nil {
		return nil
	}
	var nb []Neighbor
	for _, line := range strings.Split(string(out), "\n") {
		f := strings.Fields(line)
		if len(f) >= 3 && strings.Count(f[0], ".") == 3 && strings.Contains(f[1], "-") {
			nb = append(nb, Neighbor{IP: f[0], MAC: f[1]})
		}
	}
	return nb
}
