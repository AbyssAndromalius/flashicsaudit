package main

import (
	"bufio"
	"fmt"
	"net"
	"net/http"
	"os"
	"strings"
	"time"

	"golang.org/x/crypto/ssh"
)

// BruteResult holds a successful credential pair.
type BruteResult struct {
	Host     string `json:"host"`
	Port     int    `json:"port"`
	Proto    string `json:"proto"`
	Username string `json:"username"`
	Password string `json:"password"`
}

// BruteConfig drives the credential generation strategy.
type BruteConfig struct {
	// Users overrides the built-in username list (empty = use builtinUsers).
	Users []string
	// PassFile is a path to a newline-separated password file (empty = use builtinPasswords).
	PassFile string
	// SkipPairs disables the vendorPairs fast-track.
	SkipPairs bool
}

// builtinUsers — short ICS/OT-relevant username list.
var builtinUsers = []string{
	"admin", "administrator", "Administrator",
	"root", "user", "User",
	"operator", "Operator",
	"engineer", "Engineer",
	"manager", "Manager",
	"service", "Service",
	"guest",
	"supervisor", "technician", "maintenance",
	"plc", "scada", "hmi",
}

// builtinPasswords — password-only list: common weak + ICS/OT context.
// ~300 entries; username is injected separately.
var builtinPasswords = []string{
	// Blanks & trivials
	"", "password", "Password", "PASSWORD",
	// Numeric sequences
	"1", "12", "123", "1234", "12345", "123456", "1234567", "12345678",
	"123456789", "1234567890", "0", "00", "000", "0000", "00000", "000000",
	"1111", "11111", "111111", "2222", "3333", "4444", "5555", "6666",
	"7777", "8888", "9999", "1234321", "654321", "987654", "112233",
	// Year-based
	"2020", "2021", "2022", "2023", "2024", "2025", "2026",
	"admin2024", "admin2025", "admin2026",
	"pass2024", "pass2025",
	// Common weak
	"pass", "Pass", "passwd", "passw0rd",
	"qwerty", "azerty", "abc123", "abc", "test", "Test",
	"letmein", "welcome", "Welcome", "welcome1",
	"iloveyou", "sunshine", "princess", "dragon",
	"master", "monkey", "shadow", "superman", "batman",
	"hello", "Hello", "secret", "Secret",
	"changeme", "change_me", "default", "Default",
	"temp", "Temp", "temp123", "temp1234",
	// Username-as-password (injected dynamically in BuildCreds)
	// → handled separately
	// Vendor / product names
	"siemens", "Siemens", "Siemens#1", "!Siemens1", "adminadmin",
	"rockwell", "allen-bradley", "logix", "1756",
	"schneider", "modicon", "unity",
	"honeywell", "Honeyw3ll",
	"abb", "ABB",
	"yokogawa", "emerson", "deltav", "DeltaV",
	"omron", "mitsubishi", "beckhoff",
	"wago", "phoenix", "private", "public",
	"ge", "GE", "GEDefault", "gedefault",
	"moxa", "hirschmann", "cisco", "Cisco",
	"kepware", "ignition", "wonderware",
	"osisoft", "piadmin", "PIAdmin",
	"wincc", "scadauser",
	// ICS/OT context words
	"scada", "SCADA", "plc", "PLC", "hmi", "HMI",
	"ics", "ICS", "ot", "OT",
	"control", "Control", "controller",
	"process", "plant", "safety",
	"industrial", "Industrial",
	"operator", "engineer", "service",
	"system", "System", "network",
	// Printer defaults
	"1111", "2222", "4321", "access", "initpass",
	"x-admin", "xerox", "00000000",
	// Top-50 NCSC/HIBP list
	"password1", "password123", "passw0rd",
	"p@ssw0rd", "p@ssword", "P@ssw0rd",
	"Pa$$word", "Pa$$w0rd", "P@$$w0rd",
	"autumn", "spring", "summer", "winter",
	"football", "baseball", "soccer",
	"mustang", "starwars", "matrix",
	"trustno1", "696969", "121212",
	"superman1", "batman1",
	// Common patterns with suffix
	"admin!", "admin@", "Admin1", "Admin123",
	"root1", "root123", "User1", "user123",
	"pass1", "pass123", "pass!",
	// Short pincode-style (common on HMIs)
	"0000", "1111", "2222", "3333", "4444",
	"5555", "6666", "7777", "8888", "9999",
	"1212", "1313", "1414", "2020", "0101",
	// Site-specific (INL training context)
	"Idaho", "idaho", "Idaho1", "idaho1",
	"INL", "inl", "Inl",
	"training", "Training",
	"redteam", "blueteam",
}

// vendorPairs are specific (user, password) combos that only make sense together —
// tried as a fast-track before the matrix sweep.
var vendorPairs = [][2]string{
	// Phoenix Contact — admin:private is the documented default
	{"admin", "private"},
	// Wago
	{"admin", "wago"}, {"user", "wago"}, {"guest", "wago"}, {"wago", "wago"},
	// HP JetDirect — blank admin
	{"JetAdmin", "JetAdmin"},
	// Xerox
	{"admin", "x-admin"}, {"11111", "x-admin"},
	// Canon
	{"7654321", "7654321"},
	// Kyocera
	{"Admin", "Admin00"}, {"admin", "admin00"},
	// OSIsoft PI
	{"PIAdmin", "PIAdmin"}, {"piadmin", "piadmin"},
	{"PIARCDATA", "PIARCDATA"},
	// Ignition (Inductive Automation) — factory default
	{"admin", "password"},
	// WinCC
	{"scadauser", "scadauser"},
	// Siemens service account
	{"service", "s!emen$"},
	// FactoryTalk
	{"ftsecurity", "ftsecurity"}, {"ftadmin", "ftadmin"},
	// ABB DMS
	{"DMS", "DMS"}, {"dms", "dms"},
	// Cisco enable
	{"enable", "enable"}, {"enable", "cisco"},
	// Hirschmann
	{"admin", "private"}, {"user", "public"},
	// CODESYS default runtime (blank password)
	{"admin", ""},
	// Beckhoff TwinCAT — user 'admin' password '1'
	{"admin", "1"}, {"Administrator", "1"},
	// Schneider Modicon — uppercase USER with blank
	{"USER", ""}, {"USER", "USER"}, {"ADMIN", ""}, {"ADMIN", "ADMIN"},
	{"OPERATOR", ""}, {"OPERATOR", "OPERATOR"},
	// Emerson DeltaV
	{"DeltaVAdmin", "DeltaVAdmin"}, {"deltav", "deltav"},
	// GE CIMPLICITY
	{"cimplicity", "cimplicity"}, {"GEFanuc", "GEFanuc"},
}

// BuildCreds returns the ordered credential sequence for a brute-force run.
// Strategy:
//  1. vendorPairs fast-track (unless SkipPairs)
//  2. for each user: try user == password first, then full password list
func BuildCreds(cfg BruteConfig) [][2]string {
	users := cfg.Users
	if len(users) == 0 {
		users = builtinUsers
	}

	passwords := builtinPasswords
	if cfg.PassFile != "" {
		if loaded, err := loadPassFile(cfg.PassFile); err == nil && len(loaded) > 0 {
			passwords = loaded
			fmt.Fprintf(logWriter, "[brute] %d mots de passe chargés depuis %s\n", len(loaded), cfg.PassFile)
		} else if err != nil {
			fmt.Fprintf(logWriter, "[brute] Impossible de lire %s : %v\n", cfg.PassFile, err)
		}
	}

	seen := map[[2]string]bool{}
	var creds [][2]string

	add := func(u, p string) {
		k := [2]string{u, p}
		if !seen[k] {
			seen[k] = true
			creds = append(creds, k)
		}
	}

	// 1. Vendor pairs fast-track
	if !cfg.SkipPairs {
		for _, p := range vendorPairs {
			add(p[0], p[1])
		}
	}

	// 2. Matrix: for each user, try user==password first, then the full list
	for _, u := range users {
		add(u, u)       // username == password (very common)
		add(u, "")      // blank password
		for _, p := range passwords {
			add(u, p)
		}
	}

	return creds
}

func loadPassFile(path string) ([]string, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	var lines []string
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		if l := sc.Text(); l != "" {
			lines = append(lines, l)
		}
	}
	return lines, sc.Err()
}

// ---------------------------------------------------------------------------
// Protocol bruteforcers
// ---------------------------------------------------------------------------

func BruteSSH(host string, port int, cfg BruteConfig) *BruteResult {
	addr := fmt.Sprintf("%s:%d", host, port)
	for _, cred := range BuildCreds(cfg) {
		user, pass := cred[0], cred[1]
		sshCfg := &ssh.ClientConfig{
			User:            user,
			Auth:            []ssh.AuthMethod{ssh.Password(pass)},
			HostKeyCallback: ssh.InsecureIgnoreHostKey(),
			Timeout:         3 * time.Second,
		}
		if c, err := ssh.Dial("tcp", addr, sshCfg); err == nil {
			c.Close()
			return &BruteResult{Host: host, Port: port, Proto: "ssh", Username: user, Password: pass}
		}
	}
	return nil
}

func BruteTelnet(host string, port int, cfg BruteConfig) *BruteResult {
	addr := fmt.Sprintf("%s:%d", host, port)
	for _, cred := range BuildCreds(cfg) {
		user, pass := cred[0], cred[1]
		if ok := telnetLogin(addr, user, pass); ok {
			return &BruteResult{Host: host, Port: port, Proto: "telnet", Username: user, Password: pass}
		}
	}
	return nil
}

func BruteHTTPBasic(baseURL string, cfg BruteConfig) *BruteResult {
	client := &http.Client{Timeout: 4 * time.Second}
	for _, cred := range BuildCreds(cfg) {
		user, pass := cred[0], cred[1]
		req, _ := http.NewRequest("GET", baseURL, nil)
		req.SetBasicAuth(user, pass)
		resp, err := client.Do(req)
		if err != nil {
			continue
		}
		resp.Body.Close()
		if resp.StatusCode == 200 || resp.StatusCode == 302 {
			return &BruteResult{Host: baseURL, Port: 80, Proto: "http-basic", Username: user, Password: pass}
		}
	}
	return nil
}

// RunBrute executes credential attacks against all discovered services.
func RunBrute(r *Report, cfg BruteConfig) {
	total := len(BuildCreds(cfg))
	fmt.Fprintf(logWriter, "[brute] %d combinaisons (users=%d, passes=%d + %d paires vendeur)\n",
		total, len(usersLen(cfg)), len(passLen(cfg)), len(vendorPairs))

	var wins []BruteResult

	tryService := func(host string, port int, proto string) {
		fmt.Fprintf(logWriter, "[brute] %s %s:%d\n", proto, host, port)
		var res *BruteResult
		switch proto {
		case "ssh":
			res = BruteSSH(host, port, cfg)
		case "telnet":
			res = BruteTelnet(host, port, cfg)
		case "http":
			res = BruteHTTPBasic(fmt.Sprintf("http://%s:%d/", host, port), cfg)
		}
		if res != nil {
			fmt.Fprintf(logWriter, "[brute] ✓ TROUVÉ %s@%s:%d (%s) pass=%q\n",
				res.Username, host, port, proto, res.Password)
			wins = append(wins, *res)
		}
	}

	// Local listeners
	for _, l := range r.Network.Listeners {
		h := listenHost(l.Addr)
		switch l.Port {
		case 22:
			tryService(h, 22, "ssh")
		case 23:
			tryService(h, 23, "telnet")
		case 80, 8080:
			tryService(h, l.Port, "http")
		}
	}

	// Scan results (remote hosts)
	for _, sr := range r.ScanResults {
		for _, op := range sr.Open {
			switch op.Port {
			case 22:
				tryService(sr.IP, 22, "ssh")
			case 23:
				tryService(sr.IP, 23, "telnet")
			case 80, 8080:
				tryService(sr.IP, op.Port, "http")
			}
		}
	}

	for _, w := range wins {
		r.Add(Critical, "Credentials",
			fmt.Sprintf("Accès valide : %s@%s:%d (%s)", w.Username, w.Host, w.Port, w.Proto),
			fmt.Sprintf("Identifiants trouvés. Mot de passe : %q", w.Password),
			fmt.Sprintf("%s:%d %s user=%s pass=%s", w.Host, w.Port, w.Proto, w.Username, w.Password))
	}
	r.BruteResults = wins
}

// BruteTarget attacks a single explicit target without requiring a prior scan.
// target format: "IP:PORT/PROTO" — e.g. "192.168.10.5:23/telnet"
func BruteTarget(r *Report, target string, cfg BruteConfig) {
	slash := strings.LastIndex(target, "/")
	if slash < 0 {
		fmt.Fprintf(logWriter, "[brute-target] format attendu : IP:PORT/PROTO — reçu %q\n", target)
		return
	}
	hostPort := target[:slash]
	proto := strings.ToLower(target[slash+1:])

	host, portStr, err := net.SplitHostPort(hostPort)
	if err != nil {
		// No port — try defaults
		host = hostPort
		switch proto {
		case "ssh":
			portStr = "22"
		case "telnet":
			portStr = "23"
		default:
			portStr = "80"
		}
	}
	port := 0
	fmt.Sscanf(portStr, "%d", &port)
	if port == 0 {
		fmt.Fprintf(logWriter, "[brute-target] port invalide dans %q\n", target)
		return
	}

	fmt.Fprintf(logWriter, "[brute-target] %s %s:%d\n", proto, host, port)
	var res *BruteResult
	switch proto {
	case "ssh":
		res = BruteSSH(host, port, cfg)
	case "telnet":
		res = BruteTelnet(host, port, cfg)
	case "http":
		res = BruteHTTPBasic(fmt.Sprintf("http://%s:%d/", host, port), cfg)
	default:
		fmt.Fprintf(logWriter, "[brute-target] protocole inconnu : %s (ssh|telnet|http)\n", proto)
		return
	}

	if res != nil {
		fmt.Fprintf(logWriter, "[brute-target] ✓ TROUVÉ %s@%s:%d pass=%q\n", res.Username, host, port, res.Password)
		r.Add(Critical, "Credentials",
			fmt.Sprintf("Accès valide : %s@%s:%d (%s)", res.Username, host, port, proto),
			fmt.Sprintf("Identifiants trouvés. Mot de passe : %q", res.Password),
			fmt.Sprintf("%s:%d %s user=%s pass=%s", host, port, proto, res.Username, res.Password))
		r.BruteResults = append(r.BruteResults, *res)
	} else {
		r.Add(Info, "Credentials",
			fmt.Sprintf("Bruteforce sans résultat : %s:%d (%s)", host, port, proto),
			"Aucun identifiant trouvé dans la liste.", target)
	}
}

// ---------------------------------------------------------------------------
// Telnet login helper
// ---------------------------------------------------------------------------

func telnetLogin(addr, user, pass string) bool {
	conn, err := net.DialTimeout("tcp4", addr, 3*time.Second)
	if err != nil {
		return false
	}
	defer conn.Close()
	conn.SetDeadline(time.Now().Add(8 * time.Second))

	readUntil := func(prompts ...string) string {
		var accum strings.Builder
		tmp := make([]byte, 256)
		for {
			n, err := conn.Read(tmp)
			if err != nil || n == 0 {
				break
			}
			for i := 0; i < n; i++ {
				if tmp[i] == 0xff && i+2 < n {
					i += 2
					continue
				}
				accum.WriteByte(tmp[i])
			}
			got := strings.ToLower(accum.String())
			for _, p := range prompts {
				if strings.Contains(got, p) {
					return got
				}
			}
		}
		return accum.String()
	}

	banner := readUntil("login:", "username:", "user:", "> ", "# ", "$ ")
	if banner == "" {
		return false
	}
	conn.Write([]byte(user + "\r\n"))
	resp := readUntil("password:", "pass:", "> ", "# ", "$ ", "incorrect", "failed")
	if strings.Contains(strings.ToLower(resp), "password") ||
		strings.Contains(strings.ToLower(resp), "pass:") {
		conn.Write([]byte(pass + "\r\n"))
		resp2 := readUntil("> ", "# ", "$ ", "%", "incorrect", "failed", "denied")
		lower2 := strings.ToLower(resp2)
		for _, b := range []string{"incorrect", "failed", "denied", "invalid", "error", "bad"} {
			if strings.Contains(lower2, b) {
				return false
			}
		}
		for _, g := range []string{">", "#", "$", "%"} {
			if strings.Contains(resp2, g) {
				return true
			}
		}
	} else if strings.Contains(resp, "# ") || strings.Contains(resp, "$ ") ||
		strings.Contains(resp, "> ") {
		return true
	}
	return false
}

func listenHost(addr string) string {
	ip := net.ParseIP(addr)
	if ip == nil || ip.IsUnspecified() {
		return "127.0.0.1"
	}
	return addr
}

// helpers for log message
func usersLen(cfg BruteConfig) []string {
	if len(cfg.Users) > 0 {
		return cfg.Users
	}
	return builtinUsers
}
func passLen(cfg BruteConfig) []string {
	if cfg.PassFile != "" {
		return []string{}
	}
	return builtinPasswords
}
