package main

import (
	"fmt"
	"io"
	"net"
	"time"
)

// StartSOCKS5 starts a SOCKS5 proxy on the given address.
// All traffic is forwarded without authentication.
// Once running, point proxychains / curl --proxy socks5://IP:PORT at it.
func StartSOCKS5(addr string) {
	ln, err := net.Listen("tcp", addr)
	if err != nil {
		fmt.Fprintf(logWriter, "[socks5] Erreur bind %s : %v\n", addr, err)
		return
	}
	fmt.Fprintf(logWriter, "[socks5] Proxy SOCKS5 en écoute sur %s\n", addr)
	for {
		conn, err := ln.Accept()
		if err != nil {
			continue
		}
		go handleSOCKS5(conn)
	}
}

func handleSOCKS5(client net.Conn) {
	defer client.Close()
	client.SetDeadline(time.Now().Add(30 * time.Second))

	buf := make([]byte, 256)

	// Handshake: VER NMETHODS METHODS
	n, err := client.Read(buf)
	if err != nil || n < 2 || buf[0] != 0x05 {
		return
	}
	// Reply: no auth required
	client.Write([]byte{0x05, 0x00})

	// Request
	n, err = client.Read(buf)
	if err != nil || n < 7 || buf[0] != 0x05 || buf[1] != 0x01 {
		return
	}

	var target string
	switch buf[3] {
	case 0x01: // IPv4
		if n < 10 {
			return
		}
		ip := net.IP(buf[4:8])
		port := int(buf[8])<<8 | int(buf[9])
		target = fmt.Sprintf("%s:%d", ip.String(), port)
	case 0x03: // domain name
		nameLen := int(buf[4])
		if n < 5+nameLen+2 {
			return
		}
		name := string(buf[5 : 5+nameLen])
		port := int(buf[5+nameLen])<<8 | int(buf[5+nameLen+1])
		target = fmt.Sprintf("%s:%d", name, port)
	case 0x04: // IPv6
		if n < 22 {
			return
		}
		ip := net.IP(buf[4:20])
		port := int(buf[20])<<8 | int(buf[21])
		target = fmt.Sprintf("[%s]:%d", ip.String(), port)
	default:
		client.Write([]byte{0x05, 0x08, 0x00, 0x01, 0, 0, 0, 0, 0, 0})
		return
	}

	remote, err := net.DialTimeout("tcp", target, 10*time.Second)
	if err != nil {
		client.Write([]byte{0x05, 0x04, 0x00, 0x01, 0, 0, 0, 0, 0, 0})
		return
	}
	defer remote.Close()

	// Success reply
	client.Write([]byte{0x05, 0x00, 0x00, 0x01, 0, 0, 0, 0, 0, 0})

	client.SetDeadline(time.Time{})
	remote.SetDeadline(time.Time{})

	done := make(chan struct{}, 2)
	go func() { io.Copy(remote, client); done <- struct{}{} }()
	go func() { io.Copy(client, remote); done <- struct{}{} }()
	<-done
}
