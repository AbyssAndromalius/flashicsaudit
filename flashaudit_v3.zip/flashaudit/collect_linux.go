//go:build linux

package main

import (
	"bufio"
	"encoding/binary"
	"encoding/hex"
	"fmt"
	"net"
	"os"
	"os/exec"
	"os/user"
	"path/filepath"
	"strconv"
	"strings"
	"syscall"
	"time"
)

func collectHost(r *Report) {
	h := &r.Host
	h.OS = "linux"
	h.Arch = runtimeArch()
	hn, _ := os.Hostname()
	h.Hostname = hn
	h.IsAdmin = os.Geteuid() == 0
	if u, err := user.Current(); err == nil {
		h.CurrentUser = u.Username
	}
	h.OSVersion = osReleasePretty()
	if b, err := os.ReadFile("/proc/sys/kernel/osrelease"); err == nil {
		h.Kernel = strings.TrimSpace(string(b))
	}
	if b, err := os.ReadFile("/proc/uptime"); err == nil {
		if f := strings.Fields(string(b)); len(f) > 0 {
			if secs, e := strconv.ParseFloat(f[0], 64); e == nil {
				h.Uptime = (time.Duration(secs) * time.Second).Round(time.Minute).String()
			}
		}
	}
	h.Virtualization = detectVirtLinux()
	if d := domainLinux(); d != "" {
		h.Domain = d
	}
}

func osReleasePretty() string {
	f, err := os.Open("/etc/os-release")
	if err != nil {
		return "unknown"
	}
	defer f.Close()
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		if strings.HasPrefix(sc.Text(), "PRETTY_NAME=") {
			return strings.Trim(strings.TrimPrefix(sc.Text(), "PRETTY_NAME="), `"`)
		}
	}
	return "unknown"
}

func detectVirtLinux() string {
	if out, err := exec.Command("systemd-detect-virt").Output(); err == nil {
		v := strings.TrimSpace(string(out))
		if v != "" && v != "none" {
			return v
		}
	}
	if b, err := os.ReadFile("/sys/class/dmi/id/product_name"); err == nil {
		return strings.TrimSpace(string(b))
	}
	return ""
}

func domainLinux() string {
	if b, err := os.ReadFile("/etc/resolv.conf"); err == nil {
		for _, line := range strings.Split(string(b), "\n") {
			if strings.HasPrefix(line, "domain ") || strings.HasPrefix(line, "search ") {
				f := strings.Fields(line)
				if len(f) > 1 {
					return f[1]
				}
			}
		}
	}
	return ""
}

// --------------------------- Checks système Linux ---------------------------

func collectSystemChecks(r *Report) {
	checkSSHDConfig(r)
	checkWorldWritable(r)
	checkSUID(r)
	checkPasswdPolicy(r)
	checkSudoers(r)
	checkFirewall(r)
	checkKeysAndSecrets(r)
	checkCronRoot(r)
	checkUsers(r)
	checkCredFiles(r)
	checkDockerSocket(r)
	checkInterestingProcesses(r)
	checkWritablePasswd(r)
	checkCapabilities(r)
}

func checkSSHDConfig(r *Report) {
	b, err := os.ReadFile("/etc/ssh/sshd_config")
	if err != nil {
		return
	}
	cfg := map[string]string{}
	for _, line := range strings.Split(string(b), "\n") {
		line = strings.TrimSpace(line)
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		f := strings.Fields(line)
		if len(f) >= 2 {
			cfg[strings.ToLower(f[0])] = strings.ToLower(f[1])
		}
	}
	if cfg["permitrootlogin"] == "yes" {
		r.Add(High, "SSH", "PermitRootLogin yes", "La connexion root directe par SSH est autorisée.", "/etc/ssh/sshd_config: PermitRootLogin yes")
	}
	if cfg["passwordauthentication"] == "yes" {
		r.Add(Medium, "SSH", "Authentification par mot de passe activée", "Les connexions SSH par mot de passe sont permises (brute-force possible).", "PasswordAuthentication yes")
	}
	if cfg["permitemptypasswords"] == "yes" {
		r.Add(Critical, "SSH", "PermitEmptyPasswords yes", "SSH accepte les mots de passe vides.", "PermitEmptyPasswords yes")
	}
}

func checkWorldWritable(r *Report) {
	dirs := []string{"/etc", "/usr/bin", "/usr/local/bin", "/opt"}
	var ev []string
	for _, d := range dirs {
		filepath.Walk(d, func(path string, info os.FileInfo, err error) error {
			if err != nil || info == nil {
				return nil
			}
			if info.IsDir() && strings.Count(path, "/") > 5 {
				return filepath.SkipDir
			}
			if !info.IsDir() && info.Mode()&0002 != 0 && info.Mode()&os.ModeSymlink == 0 {
				ev = append(ev, fmt.Sprintf("%s (%s)", path, info.Mode()))
			}
			return nil
		})
	}
	if len(ev) > 0 {
		r.Add(Medium, "Permissions", fmt.Sprintf("%d fichier(s) world-writable dans des chemins sensibles", len(ev)),
			"Fichiers modifiables par tout utilisateur dans des répertoires système.", ev...)
	}
}

func checkSUID(r *Report) {
	known := map[string]bool{
		"/usr/bin/sudo": true, "/usr/bin/su": true, "/usr/bin/passwd": true,
		"/usr/bin/mount": true, "/usr/bin/umount": true, "/usr/bin/newgrp": true,
		"/usr/bin/gpasswd": true, "/usr/bin/chsh": true, "/usr/bin/chfn": true,
		"/usr/bin/pkexec": true, "/usr/lib/openssh/ssh-keysign": true,
		"/usr/bin/fusermount": true, "/usr/bin/fusermount3": true,
		"/bin/su": true, "/bin/mount": true, "/bin/umount": true,
	}
	var unusual []string
	for _, root := range []string{"/usr", "/bin", "/sbin", "/opt"} {
		filepath.Walk(root, func(path string, info os.FileInfo, err error) error {
			if err != nil || info == nil || info.IsDir() {
				return nil
			}
			if info.Mode()&os.ModeSetuid != 0 && !known[path] {
				unusual = append(unusual, path)
			}
			return nil
		})
	}
	if len(unusual) > 0 {
		r.Add(Medium, "Permissions", fmt.Sprintf("%d binaire(s) SUID non standard", len(unusual)),
			"Binaires SUID hors liste de référence — vérifier (vecteur d'élévation de privilèges).", unusual...)
	}
}

func checkPasswdPolicy(r *Report) {
	b, err := os.ReadFile("/etc/shadow")
	if err != nil {
		return // besoin de root
	}
	var noPass, noExpire []string
	for _, line := range strings.Split(string(b), "\n") {
		f := strings.Split(line, ":")
		if len(f) < 2 {
			continue
		}
		user, hash := f[0], f[1]
		if hash == "" {
			noPass = append(noPass, user)
		}
	}
	if len(noPass) > 0 {
		r.Add(Critical, "Comptes", fmt.Sprintf("%d compte(s) sans mot de passe", len(noPass)), "Comptes avec un champ de mot de passe vide dans /etc/shadow.", noPass...)
	}
	_ = noExpire
}

func checkSudoers(r *Report) {
	paths := []string{"/etc/sudoers"}
	if entries, err := os.ReadDir("/etc/sudoers.d"); err == nil {
		for _, e := range entries {
			paths = append(paths, filepath.Join("/etc/sudoers.d", e.Name()))
		}
	}
	var ev []string
	for _, p := range paths {
		b, err := os.ReadFile(p)
		if err != nil {
			continue
		}
		for _, line := range strings.Split(string(b), "\n") {
			l := strings.TrimSpace(line)
			if strings.Contains(l, "NOPASSWD") && !strings.HasPrefix(l, "#") {
				ev = append(ev, fmt.Sprintf("%s: %s", filepath.Base(p), l))
			}
		}
	}
	if len(ev) > 0 {
		r.Add(Medium, "Sudo", fmt.Sprintf("%d règle(s) sudo NOPASSWD", len(ev)), "Exécutions sudo sans mot de passe.", ev...)
	}
}

func checkFirewall(r *Report) {
	active := false
	var ev []string
	if out, err := exec.Command("ufw", "status").Output(); err == nil {
		s := string(out)
		ev = append(ev, strings.TrimSpace(strings.SplitN(s, "\n", 2)[0]))
		if strings.Contains(s, "Status: active") {
			active = true
		}
	}
	if !active {
		if out, err := exec.Command("nft", "list", "ruleset").Output(); err == nil && len(strings.TrimSpace(string(out))) > 0 {
			active = true
		}
	}
	if !active {
		if out, err := exec.Command("iptables", "-S").Output(); err == nil {
			if strings.Count(string(out), "\n") > 3 {
				active = true
			}
		}
	}
	if !active {
		r.Add(Medium, "Durcissement", "Aucun pare-feu local actif détecté", "ufw/nftables/iptables ne présentent pas de règles actives.", ev...)
	}
}

func checkKeysAndSecrets(r *Report) {
	var homes []string
	if entries, err := os.ReadDir("/home"); err == nil {
		for _, e := range entries {
			homes = append(homes, filepath.Join("/home", e.Name()))
		}
	}
	homes = append(homes, "/root")

	var unprotKeys, authKeys []string
	for _, home := range homes {
		ssh := filepath.Join(home, ".ssh")
		entries, err := os.ReadDir(ssh)
		if err != nil {
			continue
		}
		for _, e := range entries {
			p := filepath.Join(ssh, e.Name())
			info, err := e.Info()
			if err != nil {
				continue
			}
			b, _ := os.ReadFile(p)
			content := string(b)
			if strings.Contains(content, "PRIVATE KEY") {
				enc := strings.Contains(content, "ENCRYPTED") || strings.Contains(content, "bcrypt")
				if !enc {
					unprotKeys = append(unprotKeys, fmt.Sprintf("%s (clé privée NON chiffrée, %s)", p, info.Mode()))
				}
				if info.Mode()&0077 != 0 {
					unprotKeys = append(unprotKeys, fmt.Sprintf("%s (permissions trop larges %s)", p, info.Mode()))
				}
			}
			if e.Name() == "authorized_keys" {
				n := 0
				for _, ln := range strings.Split(content, "\n") {
					if strings.TrimSpace(ln) != "" && !strings.HasPrefix(strings.TrimSpace(ln), "#") {
						n++
					}
				}
				authKeys = append(authKeys, fmt.Sprintf("%s (%d clé(s) autorisée(s))", p, n))
			}
		}
	}
	if len(unprotKeys) > 0 {
		r.Add(High, "Secrets", fmt.Sprintf("%d clé(s) SSH privée(s) à risque", len(unprotKeys)),
			"Clés privées non chiffrées ou avec des permissions trop permissives.", unprotKeys...)
	}
	if len(authKeys) > 0 {
		r.Add(Info, "Accès", "Clés SSH autorisées (points d'entrée)", "Entrées authorized_keys recensées — à rapprocher des accès légitimes.", authKeys...)
	}
}

func checkCronRoot(r *Report) {
	var ev []string
	dirs := []string{"/etc/cron.d", "/etc/cron.daily", "/etc/cron.hourly", "/var/spool/cron/crontabs"}
	for _, d := range dirs {
		entries, err := os.ReadDir(d)
		if err != nil {
			continue
		}
		for _, e := range entries {
			p := filepath.Join(d, e.Name())
			if info, err := e.Info(); err == nil && !info.IsDir() && info.Mode()&0022 != 0 {
				ev = append(ev, fmt.Sprintf("%s writable (%s)", p, info.Mode()))
			}
		}
	}
	if len(ev) > 0 {
		r.Add(High, "Persistance", "Tâche cron modifiable (world/group writable)", "Fichiers cron exécutés par root et modifiables par d'autres utilisateurs.", ev...)
	}
}

func checkUsers(r *Report) {
	b, err := os.ReadFile("/etc/passwd")
	if err != nil {
		return
	}
	var uid0 []string
	shells := map[string]int{}
	for _, line := range strings.Split(string(b), "\n") {
		f := strings.Split(line, ":")
		if len(f) < 7 {
			continue
		}
		if f[2] == "0" && f[0] != "root" {
			uid0 = append(uid0, f[0])
		}
		shells[f[6]]++
	}
	if len(uid0) > 0 {
		r.Add(Critical, "Comptes", fmt.Sprintf("%d compte(s) non-root avec UID 0", len(uid0)), "Comptes disposant des privilèges root.", uid0...)
	}
}

// --------------------------- Réseau Linux (/proc/net) ---------------------------

func collectConns(r *Report) []conn {
	collectInterfaces(r)
	r.Network.Gateways = linuxGateways()
	r.Network.DNS = linuxDNS()
	r.Network.Neighbors = linuxNeighbors()

	inodePid, pidName := buildInodeMap()
	var conns []conn
	for _, spec := range []struct{ proto, path string }{
		{"tcp", "/proc/net/tcp"}, {"tcp", "/proc/net/tcp6"},
		{"udp", "/proc/net/udp"}, {"udp", "/proc/net/udp6"},
	} {
		conns = append(conns, parseProcNet(r, spec.proto, spec.path, inodePid, pidName)...)
	}
	return conns
}

var tcpStates = map[string]string{
	"01": "ESTABLISHED", "02": "SYN_SENT", "03": "SYN_RECV", "06": "TIME_WAIT",
	"0A": "LISTEN", "08": "CLOSE_WAIT",
}

func parseProcNet(r *Report, proto, path string, inodePid map[string]int, pidName map[int]string) []conn {
	f, err := os.Open(path)
	if err != nil {
		return nil
	}
	defer f.Close()
	var out []conn
	sc := bufio.NewScanner(f)
	sc.Scan() // header
	for sc.Scan() {
		fields := strings.Fields(sc.Text())
		if len(fields) < 10 {
			continue
		}
		la, lp := parseHexAddr(fields[1])
		ra, rp := parseHexAddr(fields[2])
		state := tcpStates[fields[3]]
		if proto == "udp" {
			if fields[3] == "07" {
				state = "LISTEN"
			} else {
				state = "ESTABLISHED"
			}
		}
		inode := fields[9]
		pid := inodePid[inode]
		c := conn{proto: proto, localAddr: la, localPort: lp, remoteAddr: ra, remotePort: rp, state: state, pid: pid, process: pidName[pid]}
		// garder écoutes + établies
		if state == "LISTEN" || state == "ESTABLISHED" || state == "CLOSE_WAIT" {
			out = append(out, c)
		}
	}
	return out
}

func parseHexAddr(s string) (string, int) {
	parts := strings.Split(s, ":")
	if len(parts) != 2 {
		return "", 0
	}
	portV, _ := strconv.ParseInt(parts[1], 16, 32)
	ipHex := parts[0]
	var ip net.IP
	if len(ipHex) == 8 {
		b, _ := hex.DecodeString(ipHex)
		if len(b) == 4 {
			ip = net.IPv4(b[3], b[2], b[1], b[0])
		}
	} else if len(ipHex) == 32 {
		b, _ := hex.DecodeString(ipHex)
		ip = make(net.IP, 16)
		for i := 0; i < 16; i += 4 {
			v := binary.LittleEndian.Uint32(b[i : i+4])
			binary.BigEndian.PutUint32(ip[i:i+4], v)
		}
	}
	if ip == nil {
		return "", int(portV)
	}
	return ip.String(), int(portV)
}

func buildInodeMap() (map[string]int, map[int]string) {
	inodePid := map[string]int{}
	pidName := map[int]string{}
	procs, _ := os.ReadDir("/proc")
	for _, p := range procs {
		pid, err := strconv.Atoi(p.Name())
		if err != nil {
			continue
		}
		comm, _ := os.ReadFile(fmt.Sprintf("/proc/%d/comm", pid))
		pidName[pid] = strings.TrimSpace(string(comm))
		fdDir := fmt.Sprintf("/proc/%d/fd", pid)
		fds, err := os.ReadDir(fdDir)
		if err != nil {
			continue
		}
		for _, fd := range fds {
			link, err := os.Readlink(filepath.Join(fdDir, fd.Name()))
			if err != nil {
				continue
			}
			if strings.HasPrefix(link, "socket:[") {
				inode := strings.TrimSuffix(strings.TrimPrefix(link, "socket:["), "]")
				inodePid[inode] = pid
			}
		}
	}
	return inodePid, pidName
}

func linuxGateways() []string {
	b, err := os.ReadFile("/proc/net/route")
	if err != nil {
		return nil
	}
	var gws []string
	for _, line := range strings.Split(string(b), "\n")[1:] {
		f := strings.Fields(line)
		if len(f) < 3 || f[1] != "00000000" {
			continue
		}
		v, _ := strconv.ParseUint(f[2], 16, 32)
		ip := make(net.IP, 4)
		binary.LittleEndian.PutUint32(ip, uint32(v))
		gws = appendUniq(gws, ip.String())
	}
	return gws
}

func linuxDNS() []string {
	b, err := os.ReadFile("/etc/resolv.conf")
	if err != nil {
		return nil
	}
	var dns []string
	for _, line := range strings.Split(string(b), "\n") {
		if strings.HasPrefix(line, "nameserver") {
			f := strings.Fields(line)
			if len(f) > 1 {
				dns = append(dns, f[1])
			}
		}
	}
	return dns
}

func linuxNeighbors() []Neighbor {
	out, err := exec.Command("ip", "neigh").Output()
	if err != nil {
		b, e := os.ReadFile("/proc/net/arp")
		if e != nil {
			return nil
		}
		var nb []Neighbor
		for _, line := range strings.Split(string(b), "\n")[1:] {
			f := strings.Fields(line)
			if len(f) >= 6 && f[3] != "00:00:00:00:00:00" {
				nb = append(nb, Neighbor{IP: f[0], MAC: f[3], Iface: f[5]})
			}
		}
		return nb
	}
	var nb []Neighbor
	for _, line := range strings.Split(string(out), "\n") {
		f := strings.Fields(line)
		if len(f) >= 5 && (f[len(f)-1] == "REACHABLE" || f[len(f)-1] == "STALE") {
			var ip, mac, iface string
			ip = f[0]
			for i := 0; i < len(f)-1; i++ {
				if f[i] == "dev" {
					iface = f[i+1]
				}
				if f[i] == "lladdr" {
					mac = f[i+1]
				}
			}
			if mac != "" {
				nb = append(nb, Neighbor{IP: ip, MAC: mac, Iface: iface})
			}
		}
	}
	return nb
}

func runtimeArch() string { return archString() }

// uname-based arch fallback
func archString() string {
	var uts syscall.Utsname
	if err := syscall.Uname(&uts); err == nil {
		return charsToString(uts.Machine[:])
	}
	return "unknown"
}

func charsToString(ca []int8) string {
	b := make([]byte, 0, len(ca))
	for _, c := range ca {
		if c == 0 {
			break
		}
		b = append(b, byte(c))
	}
	return string(b)
}

// checkCredFiles hunts for plaintext credentials in common config locations.
func checkCredFiles(r *Report) {
	type pattern struct {
		path    string
		glob    bool
		needsRE []string // substrings that suggest a credential line
	}
	targets := []pattern{
		{"/etc/ftp*", true, nil},
		{"/etc/proftpd*", true, nil},
		{"/var/www", true, nil},
		{"/opt", true, nil},
		{"/home", true, nil},
		{"/root", false, nil},
	}
	credKeywords := []string{
		"password", "passwd", "secret", "token", "apikey", "api_key",
		"credential", "pwd=", "pass=", "auth=", "key=",
	}
	sensitiveNames := []string{
		".env", ".env.local", ".env.prod", "credentials", "secrets",
		"config.php", "wp-config.php", "settings.py", "database.yml",
		"application.properties", "appsettings.json", "web.config",
		".htpasswd", "shadow", "passwd", "id_rsa", "id_ed25519",
		"*.pem", "*.key", "*.pfx", "*.p12",
	}

	var hits []string
	visited := map[string]bool{}

	var walk func(root string, depth int)
	walk = func(root string, depth int) {
		if depth > 6 || visited[root] {
			return
		}
		visited[root] = true
		entries, err := os.ReadDir(root)
		if err != nil {
			return
		}
		for _, e := range entries {
			p := filepath.Join(root, e.Name())
			base := strings.ToLower(e.Name())
			if e.IsDir() {
				if base == "proc" || base == "sys" || base == "dev" {
					continue
				}
				walk(p, depth+1)
				continue
			}
			// match by filename
			for _, pat := range sensitiveNames {
				if matched, _ := filepath.Match(pat, base); matched {
					hits = append(hits, p+" (nom sensible)")
					break
				}
			}
			// scan small files for credential keywords
			info, err := e.Info()
			if err != nil || info.Size() > 512*1024 {
				continue
			}
			b, err := os.ReadFile(p)
			if err != nil {
				continue
			}
			lower := strings.ToLower(string(b))
			for _, kw := range credKeywords {
				if strings.Contains(lower, kw) {
					hits = appendUniq(hits, p+" (contient: "+kw+")")
					break
				}
			}
		}
	}

	for _, t := range targets {
		if t.glob {
			matches, _ := filepath.Glob(t.path)
			for _, m := range matches {
				walk(m, 0)
			}
		} else {
			walk(t.path, 0)
		}
	}

	if len(hits) > 0 {
		r.Add(High, "Secrets", fmt.Sprintf("%d fichier(s) potentiellement sensibles", len(hits)),
			"Fichiers contenant des mots-clés d'identifiants ou nommés de manière suspecte.", hits...)
	}
}

// checkDockerSocket checks for the docker socket — trivial container escape to root.
func checkDockerSocket(r *Report) {
	info, err := os.Stat("/var/run/docker.sock")
	if err != nil {
		return
	}
	mode := info.Mode()
	r.Add(Critical, "Conteneur", "Socket Docker accessible (/var/run/docker.sock)",
		"Accès à docker.sock = escalade root triviale via: docker run -v /:/host -it alpine chroot /host sh",
		fmt.Sprintf("/var/run/docker.sock (%s)", mode))
}

// checkInterestingProcesses detects ICS software, databases, and useful services.
func checkInterestingProcesses(r *Report) {
	icsKeywords := map[string]string{
		"ignition":    "Inductive Automation Ignition (SCADA/HMI)",
		"kepserver":   "KEPServerEX (OPC UA gateway)",
		"rslogix":     "Rockwell RSLogix",
		"factorytalk": "Rockwell FactoryTalk",
		"wonderware":  "AVEVA Wonderware",
		"wincc":       "Siemens WinCC",
		"citect":      "AVEVA Citect SCADA",
		"pi ":         "OSIsoft PI historian",
		"osisoft":     "OSIsoft PI historian",
		"opc":         "OPC server/client",
		"modbus":      "Modbus service",
		"dnp3":        "DNP3 service",
		"bacnet":      "BACnet service",
	}
	dbKeywords := map[string]string{
		"mysql": "MySQL", "postgres": "PostgreSQL", "mongod": "MongoDB",
		"redis": "Redis", "mssql": "MSSQL", "oracle": "Oracle DB",
	}

	procs, _ := os.ReadDir("/proc")
	var icsFound, dbFound []string
	seen := map[string]bool{}

	for _, p := range procs {
		pid, err := strconv.Atoi(p.Name())
		if err != nil {
			continue
		}
		cmdB, err := os.ReadFile(fmt.Sprintf("/proc/%d/cmdline", pid))
		if err != nil {
			continue
		}
		cmdline := strings.ReplaceAll(strings.ToLower(string(cmdB)), "\x00", " ")
		for kw, label := range icsKeywords {
			if strings.Contains(cmdline, kw) && !seen[label] {
				seen[label] = true
				icsFound = append(icsFound, fmt.Sprintf("PID %d: %s", pid, label))
			}
		}
		for kw, label := range dbKeywords {
			if strings.Contains(cmdline, kw) && !seen[label] {
				seen[label] = true
				dbFound = append(dbFound, fmt.Sprintf("PID %d: %s", pid, label))
			}
		}
	}

	if len(icsFound) > 0 {
		r.Add(Critical, "ICS/OT", fmt.Sprintf("%d logiciel(s) industriel(s) en cours d'exécution", len(icsFound)),
			"Logiciels ICS/OT actifs sur cet hôte — cible prioritaire.", icsFound...)
	}
	if len(dbFound) > 0 {
		r.Add(Medium, "Services", fmt.Sprintf("%d base(s) de données détectée(s)", len(dbFound)),
			"Bases de données en cours d'exécution — vérifier accès et données stockées.", dbFound...)
	}
}

// checkWritablePasswd detects world-writable /etc/passwd — instant root.
func checkWritablePasswd(r *Report) {
	info, err := os.Stat("/etc/passwd")
	if err != nil {
		return
	}
	if info.Mode()&0002 != 0 {
		r.Add(Critical, "Comptes", "/etc/passwd est world-writable",
			"Modifier /etc/passwd pour ajouter un compte UID 0 sans mot de passe = root immédiat.",
			fmt.Sprintf("/etc/passwd (%s)", info.Mode()))
	}
}

// checkCapabilities looks for dangerous Linux capabilities on binaries.
func checkCapabilities(r *Report) {
	out, err := exec.Command("getcap", "-r", "/", "--").Output()
	if err != nil {
		// getcap not available or no caps found
		return
	}
	dangerous := map[string]string{
		"cap_setuid":   "permet setuid → root trivial",
		"cap_net_raw":  "capture réseau sans root",
		"cap_dac_read_search": "lecture de tout fichier",
		"cap_sys_admin": "quasi-root",
		"cap_sys_ptrace": "peut ptrace tout processus",
	}
	var ev []string
	for _, line := range strings.Split(string(out), "\n") {
		line = strings.TrimSpace(line)
		if line == "" {
			continue
		}
		lower := strings.ToLower(line)
		for cap_, desc := range dangerous {
			if strings.Contains(lower, cap_) {
				ev = append(ev, line+" ("+desc+")")
			}
		}
	}
	if len(ev) > 0 {
		r.Add(High, "Permissions", fmt.Sprintf("%d binaire(s) avec capabilities dangereuses", len(ev)),
			"Binaires avec capabilities Linux permettant une élévation de privilèges.", ev...)
	}
}
